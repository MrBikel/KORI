package com.aistudio.moneydiary.mndytr.ui

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.aistudio.moneydiary.mndytr.data.local.database.AppDatabase
import com.aistudio.moneydiary.mndytr.domain.model.DiaryEntryType
import com.aistudio.moneydiary.mndytr.domain.model.NecessityClassification
import com.aistudio.moneydiary.mndytr.domain.service.CategoryIconResolver
import com.aistudio.moneydiary.mndytr.domain.service.DataExportService
import com.aistudio.moneydiary.mndytr.domain.service.FinancialService
import com.aistudio.moneydiary.mndytr.ui.theme.DarkKoriBackground
import com.aistudio.moneydiary.mndytr.ui.theme.DarkKoriExpense
import com.aistudio.moneydiary.mndytr.ui.theme.DarkKoriIncome
import com.aistudio.moneydiary.mndytr.ui.theme.DarkKoriPrimary
import com.aistudio.moneydiary.mndytr.ui.theme.DarkKoriSurface
import com.aistudio.moneydiary.mndytr.ui.theme.KoriTypographyTokens
import com.aistudio.moneydiary.mndytr.ui.theme.LightKoriBackground
import com.aistudio.moneydiary.mndytr.ui.theme.LightKoriExpense
import com.aistudio.moneydiary.mndytr.ui.theme.LightKoriIncome
import com.aistudio.moneydiary.mndytr.ui.theme.LightKoriPrimary
import com.aistudio.moneydiary.mndytr.ui.theme.LightKoriSurface
import com.aistudio.moneydiary.mndytr.ui.util.BengaliFormatter
import com.aistudio.moneydiary.mndytr.ui.viewmodel.DiaryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class KoriMasterSuiteTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var db: AppDatabase
    private lateinit var context: Context

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
        Dispatchers.resetMain()
    }

    private fun createViewModel(): DiaryViewModel {
        return DiaryViewModel(db = db, financialService = FinancialService(db), ioDispatcher = testDispatcher)
    }

    private fun resolveProjectFile(relativePath: String): File {
        val direct = File(relativePath)
        if (direct.exists()) return direct
        val inApplet = File("/app/applet", relativePath)
        if (inApplet.exists()) return inApplet
        val inApp = File("app", relativePath)
        if (inApp.exists()) return inApp
        return direct
    }

    // 1. Font files verification
    @Test
    fun testFontFilesExistAndNonZero() {
        val fontNames = listOf(
            "hind_siliguri_regular.ttf",
            "hind_siliguri_medium.ttf",
            "hind_siliguri_semibold.ttf",
            "hind_siliguri_bold.ttf",
            "noto_serif_bengali_regular.ttf",
            "noto_serif_bengali_medium.ttf",
            "noto_serif_bengali_semibold.ttf"
        )
        val fontDir = resolveProjectFile("app/src/main/res/font")
        assertTrue("Font directory should exist: ${fontDir.absolutePath}", fontDir.exists() && fontDir.isDirectory)
        for (name in fontNames) {
            val file = File(fontDir, name)
            assertTrue("Font file $name should exist", file.exists())
            assertTrue("Font file $name should be non-empty", file.length() > 0)
        }
    }

    // 2. Font licenses verification
    @Test
    fun testFontLicensesExist() {
        val siliguriLicense = resolveProjectFile("LICENSES/OFL-HindSiliguri.txt")
        val notoLicense = resolveProjectFile("LICENSES/OFL-NotoSerifBengali.txt")
        assertTrue("Hind Siliguri license must exist: ${siliguriLicense.absolutePath}", siliguriLicense.exists() && siliguriLicense.length() > 0)
        assertTrue("Noto Serif Bengali license must exist: ${notoLicense.absolutePath}", notoLicense.exists() && notoLicense.length() > 0)
    }

    // 3. Exact typography tokens
    @Test
    fun testTypographyTokens() {
        assertEquals(26f, KoriTypographyTokens.Wordmark.fontSize.value)
        assertEquals(34f, KoriTypographyTokens.PrimaryAmount.fontSize.value)
        assertEquals(22f, KoriTypographyTokens.SecondaryAmount.fontSize.value)
        assertEquals(17f, KoriTypographyTokens.TransactionAmount.fontSize.value)
        assertEquals(21f, KoriTypographyTokens.DiaryDate.fontSize.value)
        assertEquals(22f, KoriTypographyTokens.ScreenTitle.fontSize.value)
        assertEquals(18f, KoriTypographyTokens.SectionTitle.fontSize.value)
        assertEquals(16f, KoriTypographyTokens.EntryTitle.fontSize.value)
        assertEquals(16f, KoriTypographyTokens.Body.fontSize.value)
        assertEquals(14f, KoriTypographyTokens.SecondaryBody.fontSize.value)
        assertEquals(13f, KoriTypographyTokens.Metadata.fontSize.value)
        assertEquals(16f, KoriTypographyTokens.PrimaryButton.fontSize.value)
        assertEquals(13f, KoriTypographyTokens.BottomNav.fontSize.value)
        assertEquals(17f, KoriTypographyTokens.FormInput.fontSize.value)
        assertEquals(14f, KoriTypographyTokens.FormLabel.fontSize.value)
        assertEquals(20f, KoriTypographyTokens.EmptyStateTitle.fontSize.value)
        assertEquals(18f, KoriTypographyTokens.InsightTitle.fontSize.value)
    }

    // 4. Exact theme color definitions
    @Test
    fun testThemeColorHexValues() {
        fun androidx.compose.ui.graphics.Color.argbInt(): Int = (this.value.toLong() ushr 32).toInt()

        // Light Theme
        assertEquals(0xFFF6F4EE.toInt(), LightKoriBackground.argbInt())
        assertEquals(0xFFFFFFFF.toInt(), LightKoriSurface.argbInt())
        assertEquals(0xFF234E45.toInt(), LightKoriPrimary.argbInt())
        assertEquals(0xFF2F7556.toInt(), LightKoriIncome.argbInt())
        assertEquals(0xFFA64F4C.toInt(), LightKoriExpense.argbInt())

        // Dark Theme
        assertEquals(0xFF111513.toInt(), DarkKoriBackground.argbInt())
        assertEquals(0xFF191F1C.toInt(), DarkKoriSurface.argbInt())
        assertEquals(0xFF7CB5A3.toInt(), DarkKoriPrimary.argbInt())
        assertEquals(0xFF74BD91.toInt(), DarkKoriIncome.argbInt())
        assertEquals(0xFFD77B76.toInt(), DarkKoriExpense.argbInt())
    }

    // 5. Bengali & English numerals and Taka formatting
    @Test
    fun testBengaliNumeralAndTakaFormatting() {
        assertEquals("৳ ০", BengaliFormatter.formatPaisa(0L, useBengaliDigits = true, showDecimals = false))
        assertEquals("৳ ১০", BengaliFormatter.formatPaisa(1000L, useBengaliDigits = true, showDecimals = false))
        assertEquals("৳ ৪৫০", BengaliFormatter.formatPaisa(45000L, useBengaliDigits = true, showDecimals = false))
        assertEquals("৳ ১,২৫০", BengaliFormatter.formatPaisa(125000L, useBengaliDigits = true, showDecimals = false))
        assertEquals("৳ ১২,৫০,০০০", BengaliFormatter.formatPaisa(125000000L, useBengaliDigits = true, showDecimals = false))

        // English digits
        assertEquals("৳ 0", BengaliFormatter.formatPaisa(0L, useBengaliDigits = false, showDecimals = false))
        assertEquals("৳ 450", BengaliFormatter.formatPaisa(45000L, useBengaliDigits = false, showDecimals = false))
    }

    // 6. Bengali Conjunct Strings & Literals Safety
    @Test
    fun testBengaliConjunctAndComplexStrings() {
        val testStrings = listOf(
            "ক্ষ", "জ্ঞ", "ত্র", "শ্র", "ন্দ্র", "ষ্ট্র", "দ্ধ", "স্ত্রী",
            "প্রয়োজনীয়", "মিতব্যয়িতা", "বিদ্যুৎ", "ঔষধ", "৳", "০১২৩৪৫৬৭৮৯",
            "Wi-Fi বিল", "bKash থেকে", "৳ ১,২৫০.৫০"
        )
        for (str in testStrings) {
            assertTrue(str.isNotEmpty())
            assertEquals(str, str)
        }
    }

    // 7. Icon mapping deterministic engine
    @Test
    fun testCategoryIconDeterminism() {
        assertEquals("menu_book", CategoryIconResolver.suggestIconKey("বই কেনা"))
        assertEquals("menu_book", CategoryIconResolver.suggestIconKey("বই"))
        assertEquals("medication", CategoryIconResolver.suggestIconKey("ওষুধ"))
        assertEquals("local_hospital", CategoryIconResolver.suggestIconKey("চিকিৎসা"))
        assertEquals("home", CategoryIconResolver.suggestIconKey("বাড়িভাড়া"))
        assertEquals("home", CategoryIconResolver.suggestIconKey("বাসাভাড়া"))
        assertEquals("bolt", CategoryIconResolver.suggestIconKey("বিদ্যুৎ বিল"))
        assertEquals("wifi", CategoryIconResolver.suggestIconKey("Wi-Fi"))
        assertEquals("wifi", CategoryIconResolver.suggestIconKey("ইন্টারনেট"))
        assertEquals("phone_android", CategoryIconResolver.suggestIconKey("মোবাইল"))
        assertEquals("groups", CategoryIconResolver.suggestIconKey("পরিবার"))
        assertEquals("favorite", CategoryIconResolver.suggestIconKey("স্ত্রী"))
        assertEquals("school", CategoryIconResolver.suggestIconKey("শিক্ষা"))
        assertEquals("directions_bus", CategoryIconResolver.suggestIconKey("যাতায়াত"))
        assertEquals("directions_bus", CategoryIconResolver.suggestIconKey("রিকশা"))
        assertEquals("restaurant", CategoryIconResolver.suggestIconKey("খাবার"))
        assertEquals("local_cafe", CategoryIconResolver.suggestIconKey("চা"))
        assertEquals("edit", CategoryIconResolver.suggestIconKey("লেখালেখি"))
        assertEquals("laptop", CategoryIconResolver.suggestIconKey("অনলাইন কাজ"))
        assertEquals("payments", CategoryIconResolver.suggestIconKey("বেতন"))
        assertEquals("category", CategoryIconResolver.suggestIconKey("অজানা কোনো খাত"))
    }

    // 8. Empty-first state on new launch
    @Test
    fun testEmptyFirstState() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        viewModel.completeFirstLaunchSetup(useBengaliDigits = true)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals(0, state.allDiaryEntries.size)
        assertEquals(0, state.todayEntries.size)
        assertEquals(0L, state.todaySummary.todayIncomePaisa)
        assertEquals(0L, state.todaySummary.todayExpensePaisa)
        assertEquals(0L, state.todaySummary.todayNetChangePaisa)
        assertFalse(state.todaySummary.hasEntriesToday)
    }

    // 9. Standard Acceptance Scenario with Source persistence and no account creation
    @Test
    fun testAcceptanceDataFlow() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        viewModel.completeFirstLaunchSetup(useBengaliDigits = true)
        advanceUntilIdle()

        // 1. Expense: ৳450, ওষুধ, বেতন থেকে, প্রয়োজনীয়, জ্বরের ওষুধ
        viewModel.recordDiaryEntry(
            type = DiaryEntryType.EXPENSE,
            amountPaisa = 45000L,
            categoryId = null,
            sourceDescription = "বেতন থেকে",
            description = "জ্বরের ওষুধ",
            notes = "প্যারাসিটামল",
            necessity = NecessityClassification.ESSENTIAL
        )
        advanceUntilIdle()

        // 2. Income: ৳500, অনলাইন কাজ, গ্রাহকের দেওয়া টাকা
        viewModel.recordDiaryEntry(
            type = DiaryEntryType.INCOME,
            amountPaisa = 50000L,
            categoryId = null,
            sourceDescription = "গ্রাহকের দেওয়া টাকা",
            description = "অনলাইন কাজ"
        )
        advanceUntilIdle()

        // 3. Expense: ৳10, চা, পকেটের টাকা
        viewModel.recordDiaryEntry(
            type = DiaryEntryType.EXPENSE,
            amountPaisa = 1000L,
            categoryId = null,
            sourceDescription = "পকেটের টাকা",
            description = "চা",
            necessity = NecessityClassification.REGULAR
        )
        advanceUntilIdle()

        viewModel.refreshNow()
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals(50000L, state.todaySummary.todayIncomePaisa)
        assertEquals(46000L, state.todaySummary.todayExpensePaisa)
        assertEquals(4000L, state.todaySummary.todayNetChangePaisa)
        assertEquals(3, state.todayEntries.size)

        // Verify CSV export format
        val csv = DataExportService.generateCsv(state.allDiaryEntries, includePrivateNotes = true)
        assertTrue(csv.contains("Income,500.0"))
        assertTrue(csv.contains("Expense,450.0"))
        assertTrue(csv.contains("Expense,10.0"))
        assertTrue(csv.contains("বেতন থেকে"))
        assertTrue(csv.contains("গ্রাহকের দেওয়া টাকা"))
        assertTrue(csv.contains("পকেটের টাকা"))

        // Verify JSON export format
        val json = DataExportService.generateJson(state.allDiaryEntries, includePrivateNotes = true)
        assertTrue(json.contains("\"amountPaisa\": 45000"))
        assertTrue(json.contains("\"amountPaisa\": 50000"))
        assertTrue(json.contains("\"amountPaisa\": 1000"))
    }

    // 10. Goals and Frugality tracking
    @Test
    fun testFrugalityGoalProgressCalculation() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        viewModel.completeFirstLaunchSetup(useBengaliDigits = true)
        advanceUntilIdle()

        // Add monthly goal of ৳5,000 (500,000 paisa)
        viewModel.addFrugalityGoal(
            title = "মাসিক চা-নাশতা সীমা",
            goalType = "CATEGORY_CEILING_MONTHLY",
            targetAmountPaisa = 500000L,
            categoryId = null
        )
        advanceUntilIdle()

        // Record spending of ৳1,000 (100,000 paisa)
        viewModel.recordDiaryEntry(
            type = DiaryEntryType.EXPENSE,
            amountPaisa = 100000L,
            categoryId = null,
            sourceDescription = "পকেট",
            description = "চা-নাশতা"
        )
        advanceUntilIdle()

        viewModel.refreshNow()
        advanceUntilIdle()

        val state = viewModel.uiState.value
        val progressList = state.analysisInsights?.frugalityGoalsProgress
        assertNotNull(progressList)
        assertTrue(progressList!!.isNotEmpty())
        val progress = progressList.first()
        assertEquals(100000L, progress.currentSpendingPaisa)
        assertEquals(400000L, progress.remainingAllowancePaisa)
        assertEquals(20.0, progress.percentageUsed, 0.01)
        assertFalse(progress.isExceeded)
    }
}
