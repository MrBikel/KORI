package com.aistudio.moneydiary.mndytr.ui.screens

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.moneydiary.mndytr.BuildConfig
import com.aistudio.moneydiary.mndytr.domain.service.DataExportService
import com.aistudio.moneydiary.mndytr.ui.state.DiaryUiState
import com.aistudio.moneydiary.mndytr.ui.theme.*

@Composable
fun MoreScreen(
    state: DiaryUiState,
    onManageCategoriesClick: () -> Unit,
    onFrugalityGoalsClick: () -> Unit,
    onReminderSettingsClick: () -> Unit,
    onToggleNumeralSystem: (Boolean) -> Unit,
    onToggleTheme: (String) -> Unit,
    onDiagnosticsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showExportDialog by remember { mutableStateOf(false) }
    var exportFormat by remember { mutableStateOf("CSV") } // CSV or JSON
    var exportIncludeNotes by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showCloudNotice by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title Header
        item {
            Text(
                text = "আরও সেটিংস ও অপশন",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
        }

        // Section 1: Categories & Goals
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    // ব্যয়ের খাত
                    MoreMenuItem(
                        icon = Icons.Default.TrendingDown,
                        iconTint = LightKoriExpense,
                        title = "ব্যয়ের খাত",
                        subtitle = "খরচের খাতসমূহ পরিচালনা ও নতুন খাত যোগ",
                        onClick = onManageCategoriesClick,
                        tag = "expense_categories_item"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // আয়ের খাত
                    MoreMenuItem(
                        icon = Icons.Default.TrendingUp,
                        iconTint = LightKoriIncome,
                        title = "আয়ের খাত",
                        subtitle = "উপার্জনের খাতসমূহ সাজানো ও যোগ করা",
                        onClick = onManageCategoriesClick,
                        tag = "income_categories_item"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // খাত ও দ্রুত লেখা
                    MoreMenuItem(
                        icon = Icons.Default.Category,
                        iconTint = MaterialTheme.colorScheme.primary,
                        title = "খাত ও দ্রুত লেখা",
                        subtitle = "আইকন নির্ধারণ ও পুনরাবৃত্তি খাতের সাজসজ্জা",
                        onClick = onManageCategoriesClick,
                        tag = "categories_quick_write_item"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // মিতব্যয়িতার লক্ষ্য
                    MoreMenuItem(
                        icon = Icons.Default.TrackChanges,
                        iconTint = LightKoriWarning,
                        title = "মিতব্যয়িতার লক্ষ্য",
                        subtitle = "বাজেট এবং খরচ কমানোর পরিকল্পনা ও সীমা",
                        onClick = onFrugalityGoalsClick,
                        tag = "frugality_goals_item"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // নোটিফিকেশন
                    MoreMenuItem(
                        icon = Icons.Default.Notifications,
                        iconTint = LightKoriInsight,
                        title = "নোটিফিকেশন",
                        subtitle = if (state.isDailyReminderEnabled) "দৈনিক ও নিয়মিত অনুস্মারক চালু রয়েছে" else "অনুস্মারক বন্ধ রয়েছে",
                        onClick = onReminderSettingsClick,
                        tag = "reminder_settings_item"
                    )
                }
            }
        }

        // Section 2: Preferences, Language, Theme & Export
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    // ভাষা ও অঙ্ক
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleNumeralSystem(!state.useBengaliDigits) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Numbers,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "ভাষা ও অঙ্ক",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                                )
                                Text(
                                    text = if (state.useBengaliDigits) "বাংলা সংখ্যা (১, ২, ৩...)" else "ইংরেজি সংখ্যা (1, 2, 3...)",
                                    style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                        Switch(
                            checked = state.useBengaliDigits,
                            onCheckedChange = onToggleNumeralSystem,
                            modifier = Modifier.testTag("numeral_toggle_switch")
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // থিম
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "থিম",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                                )
                                Text(
                                    text = when (state.themeMode) {
                                        "LIGHT" -> "লাইট থিম"
                                        "DARK" -> "ডার্ক থিম"
                                        else -> "সিস্টেম অনুযায়ী"
                                    },
                                    style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = state.themeMode == "SYSTEM",
                                onClick = { onToggleTheme("SYSTEM") },
                                label = { Text("স্বয়ংক্রিয়", style = MaterialTheme.typography.labelSmall) }
                            )
                            FilterChip(
                                selected = state.themeMode == "LIGHT",
                                onClick = { onToggleTheme("LIGHT") },
                                label = { Text("লাইট", style = MaterialTheme.typography.labelSmall) }
                            )
                            FilterChip(
                                selected = state.themeMode == "DARK",
                                onClick = { onToggleTheme("DARK") },
                                label = { Text("ডার্ক", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // ডেটা Export
                    MoreMenuItem(
                        icon = Icons.Default.FileDownload,
                        iconTint = LightKoriInsight,
                        title = "ডেটা Export",
                        subtitle = "CSV বা JSON ফরম্যাটে স্থানীয় ডিভাইসে ব্যাকআপ নিন",
                        onClick = { showExportDialog = true },
                        tag = "export_data_item"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // Cloud ও Backup
                    MoreMenuItem(
                        icon = Icons.Default.CloudQueue,
                        iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                        title = "Cloud ও Backup",
                        subtitle = "এখনো সংযুক্ত নয়",
                        onClick = { showCloudNotice = true },
                        tag = "cloud_sync_item"
                    )
                }
            }
        }

        // Section 3: Privacy & About
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    // গোপনীয়তা
                    MoreMenuItem(
                        icon = Icons.Default.Security,
                        iconTint = LightKoriIncome,
                        title = "গোপনীয়তা",
                        subtitle = "আপনার সমস্ত ডেটা সম্পূর্ণ অফলাইন ও এই ফোনেই সংরক্ষিত",
                        onClick = { showPrivacyDialog = true },
                        tag = "privacy_policy_item"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // কড়ি সম্পর্কে
                    MoreMenuItem(
                        icon = Icons.Default.Info,
                        iconTint = MaterialTheme.colorScheme.primary,
                        title = "কড়ি সম্পর্কে",
                        subtitle = "সংস্করণ ২.০ • শান্ত ও ব্যক্তিগত আয়-ব্যয় ডায়েরি",
                        onClick = { showAboutDialog = true },
                        tag = "about_kori_item"
                    )
                }
            }
        }

        // Diagnostic Capture Menu (ONLY compiled & visible in Diagnostic builds)
        if (BuildConfig.IS_DIAGNOSTIC) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    MoreMenuItem(
                        icon = Icons.Default.BugReport,
                        iconTint = LightKoriExpense,
                        title = "ডায়াগনস্টিকস (শুধু ডায়াগনস্টিক বিল্ড)",
                        subtitle = "সিস্টেম তথ্য, ডেটাবেস সাইজ ও ক্র্যাশ রিপোর্ট",
                        onClick = onDiagnosticsClick,
                        tag = "diagnostics_menu_item"
                    )
                }
            }
        }

        // App Information Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "কড়ি • সংস্করণ ২.০",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                )
                Text(
                    text = "প্রতিটি কড়ির নির্ভুল হিসাব • সম্পূর্ণ অফলাইন ও ব্যক্তিগত",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                )
            }
        }
    }

    // Export Dialog with Real CSV/JSON Sharing
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("ডেটা Export") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "আপনার সমস্ত আয়-ব্যয়ের হিসাব স্থানীয় ফাইলে এক্সপোর্ট করে ডিভাইসে সংরক্ষণ বা শেয়ার করতে পারেন।",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Text(
                        text = "ফরম্যাট নির্বাচন করুন:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = exportFormat == "CSV",
                            onClick = { exportFormat = "CSV" },
                            label = { Text("CSV (এক্সেল ফ্রেন্ডলি)") }
                        )
                        FilterChip(
                            selected = exportFormat == "JSON",
                            onClick = { exportFormat = "JSON" },
                            label = { Text("JSON") }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ব্যক্তিগত ডায়েরি নোট যুক্ত করুন",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Switch(
                            checked = exportIncludeNotes,
                            onCheckedChange = { exportIncludeNotes = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val shareIntent = DataExportService.exportAndShare(
                            context = context,
                            entries = state.allDiaryEntries,
                            format = exportFormat,
                            includePrivateNotes = exportIncludeNotes
                        )
                        if (shareIntent != null) {
                            context.startActivity(shareIntent)
                        }
                        showExportDialog = false
                    }
                ) {
                    Text("এক্সপোর্ট করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    if (showCloudNotice) {
        AlertDialog(
            onDismissRequest = { showCloudNotice = false },
            title = { Text("Cloud ও Backup") },
            text = {
                Text("ক্লাউড ব্যাকআপ এবং সিঙ্ক এখনো সংযুক্ত নয়। কড়ি বর্তমানে শতভাগ অফলাইন ও আপনার ডিভাইসের অভ্যন্তরীণ মেমোরিতে নিরাপদে সংরক্ষিত।")
            },
            confirmButton = {
                Button(onClick = { showCloudNotice = false }) {
                    Text("ঠিক আছে")
                }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("গোপনীয়তা ও নিরাপত্তা") },
            text = {
                Text("কড়ি কোনো ব্যক্তিগত তথ্য (পূর্ণ নাম, ইমেইল, পাসওয়ার্ড, ফোন নম্বর, জন্মতারিখ, ঠিকানা বা প্রোফাইল ছবি) সংগ্রহ বা ইন্টারনেটে প্রেরণ করে না। আপনার সমস্ত আর্থিক হিসাব শুধুমাত্র আপনার ডিভাইসে Room ডেটাবেসে থাকে।")
            },
            confirmButton = {
                Button(onClick = { showPrivacyDialog = false }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("কড়ি সম্পর্কে") },
            text = {
                Text("কড়ি হলো বাংলা ভাষায় তৈরি একটি মার্জিত ব্যক্তিগত আর্থিক ডায়েরি।\nপ্রতিটি কড়ির নির্ভুল হিসাব রাখার মাধ্যমে ব্যয় সচেতনতা ও মিতব্যয়িতা গড়ে তোলাই এর মূল উদ্দেশ্য।")
            },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }) {
                    Text("ঠিক আছে")
                }
            }
        )
    }
}

@Composable
fun MoreMenuItem(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(24.dp)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(20.dp)
        )
    }
}
