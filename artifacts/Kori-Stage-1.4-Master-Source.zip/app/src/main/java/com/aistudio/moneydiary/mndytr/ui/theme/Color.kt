package com.aistudio.moneydiary.mndytr.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// KORI VERSION 2.0 PREMIUM MINIMAL DESIGN SYSTEM
// ==========================================

// --- Light Theme Colors ---
val LightKoriBackground = Color(0xFFF6F4EE) // Canvas: #F6F4EE
val LightKoriSurface = Color(0xFFFFFFFF)    // Surface: #FFFFFF
val LightKoriPrimary = Color(0xFF234E45)    // Primary: #234E45
val LightKoriPrimarySoft = Color(0xFFE5EFEB)// Primary Soft: #E5EFEB
val LightKoriTextPrimary = Color(0xFF17201D)// Text Main: #17201D
val LightKoriTextSecondary = Color(0xFF68716D)// Text Muted: #68716D
val LightKoriBorder = Color(0xFFE4E6E2)     // Border: #E4E6E2
val LightKoriIncome = Color(0xFF2F7556)     // Income: #2F7556
val LightKoriExpense = Color(0xFFA64F4C)    // Expense: #A64F4C
val LightKoriInsight = Color(0xFF486B82)    // Insight: #486B82
val LightKoriWarning = Color(0xFF966A27)    // Warning: #966A27

// --- Dark Theme Colors ---
val DarkKoriBackground = Color(0xFF111513)  // Canvas: #111513
val DarkKoriSurface = Color(0xFF191F1C)     // Surface: #191F1C
val DarkKoriRaisedSurface = Color(0xFF222925)// Raised: #222925
val DarkKoriPrimary = Color(0xFF7CB5A3)     // Primary: #7CB5A3
val DarkKoriPrimarySoft = Color(0xFF294239)// Primary Soft: #294239
val DarkKoriTextPrimary = Color(0xFFF2F4F2) // Text Main: #F2F4F2
val DarkKoriTextSecondary = Color(0xFFAEB6B2)// Text Muted: #AEB6B2
val DarkKoriBorder = Color(0xFF2E3732)      // Border: #2E3732
val DarkKoriIncome = Color(0xFF74BD91)      // Income: #74BD91
val DarkKoriExpense = Color(0xFFD77B76)     // Expense: #D77B76
val DarkKoriInsight = Color(0xFF86AFCB)     // Insight: #86AFCB
val DarkKoriWarning = Color(0xFFD0A15E)     // Warning: #D0A15E

// Backward compatibility aliases
val PrimaryEmerald = LightKoriPrimary
val IncomeGreen = LightKoriIncome
val ExpenseRed = LightKoriExpense
val SecondaryGold = LightKoriWarning
val LightBackground = LightKoriBackground
val LightSurface = LightKoriSurface
val DarkBackground = DarkKoriBackground
val DarkSurface = DarkKoriSurface

val IncomeGreenContainer = Color(0xFFE8F5E9)
val ExpenseRedContainer = Color(0xFFFFEBEE)

val AdvanceAmber = Color(0xFFE65100)
val AdvanceAmberContainer = Color(0xFFFFF3E0)
val TransferTeal = Color(0xFF00695C)
val TransferTealContainer = Color(0xFFE0F2F1)
val ReceivableBlue = Color(0xFF1565C0)
val ReceivableBlueContainer = Color(0xFFE3F2FD)
