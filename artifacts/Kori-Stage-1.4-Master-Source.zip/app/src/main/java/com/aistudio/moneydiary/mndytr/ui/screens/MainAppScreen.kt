package com.aistudio.moneydiary.mndytr.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aistudio.moneydiary.mndytr.domain.model.DiaryEntry
import com.aistudio.moneydiary.mndytr.domain.model.DiaryEntryType
import com.aistudio.moneydiary.mndytr.domain.service.DiagnosticService
import com.aistudio.moneydiary.mndytr.ui.dialogs.*
import com.aistudio.moneydiary.mndytr.ui.state.ActiveDialog
import com.aistudio.moneydiary.mndytr.ui.state.AppNavTab
import com.aistudio.moneydiary.mndytr.ui.viewmodel.DiaryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: DiaryViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedEntryForDetail by remember { mutableStateOf<DiaryEntry?>(null) }
    var isQuickEntrySheetOpen by remember { mutableStateOf(false) }

    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    if (!state.isSetupCompleted) {
        FirstLaunchSetupScreen(
            onComplete = { useBn, drafts, lang, curr, theme, reminder, name ->
                viewModel.completeFirstLaunchSetup(useBn, drafts, lang, curr, theme, reminder, name)
            }
        )
        return
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                // 1. আজ (Today)
                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.TODAY,
                    onClick = { viewModel.selectTab(AppNavTab.TODAY) },
                    icon = { Icon(Icons.Default.Today, contentDescription = "আজ") },
                    label = { Text("আজ", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_today")
                )

                // 2. ডায়েরি (Diary)
                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.DIARY,
                    onClick = { viewModel.selectTab(AppNavTab.DIARY) },
                    icon = { Icon(Icons.Default.AutoStories, contentDescription = "ডায়েরি") },
                    label = { Text("ডায়েরি", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_diary")
                )

                // 3. বিশ্লেষণ (Analysis)
                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.ANALYSIS,
                    onClick = { viewModel.selectTab(AppNavTab.ANALYSIS) },
                    icon = { Icon(Icons.Default.Insights, contentDescription = "বিশ্লেষণ") },
                    label = { Text("বিশ্লেষণ", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_analysis")
                )

                // 4. আরও (More)
                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.MORE,
                    onClick = { viewModel.selectTab(AppNavTab.MORE) },
                    icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "আরও") },
                    label = { Text("আরও", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_more")
                )
            }
        },
        floatingActionButton = {
            if (state.selectedTab == AppNavTab.TODAY || state.selectedTab == AppNavTab.DIARY) {
                ExtendedFloatingActionButton(
                    onClick = { viewModel.openDialog(ActiveDialog.AddExpense) },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                    text = { Text("হিসাব লিখুন", style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp)) },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("quick_add_fab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (state.selectedTab) {
                AppNavTab.TODAY -> {
                    TodayScreen(
                        state = state,
                        onAddExpenseClick = { viewModel.openDialog(ActiveDialog.AddExpense) },
                        onAddIncomeClick = { viewModel.openDialog(ActiveDialog.AddIncome) },
                        onEntryClick = { entry ->
                            selectedEntryForDetail = entry
                            viewModel.openDialog(ActiveDialog.EntryDetail(entry))
                        }
                    )
                }

                AppNavTab.DIARY -> {
                    DiaryScreen(
                        state = state,
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onTypeFilterChange = { viewModel.setTypeFilter(it) },
                        onCategoryFilterChange = { viewModel.setCategoryFilter(it) },
                        onNecessityFilterChange = { viewModel.setNecessityFilter(it) },
                        onEntryClick = { entry ->
                            selectedEntryForDetail = entry
                            viewModel.openDialog(ActiveDialog.EntryDetail(entry))
                        },
                        onAddEntryClick = { viewModel.openDialog(ActiveDialog.AddExpense) }
                    )
                }

                AppNavTab.ANALYSIS -> {
                    AnalysisScreen(
                        state = state,
                        onAddGoalClick = { viewModel.openDialog(ActiveDialog.AddFrugalityGoal) }
                    )
                }

                AppNavTab.MORE -> {
                    MoreScreen(
                        state = state,
                        onManageCategoriesClick = { viewModel.openDialog(ActiveDialog.ManageCategories) },
                        onFrugalityGoalsClick = { viewModel.openDialog(ActiveDialog.AddFrugalityGoal) },
                        onReminderSettingsClick = { viewModel.openDialog(ActiveDialog.ReminderSettings) },
                        onToggleNumeralSystem = {
                            viewModel.updateSetting("numeral_system", if (it) "bn" else "en")
                        },
                        onToggleTheme = { viewModel.updateSetting("theme_mode", it) },
                        onDiagnosticsClick = { viewModel.openDialog(ActiveDialog.Diagnostics) }
                    )
                }
            }
        }

        // Active Dialogs Routing
        when (val active = state.activeDialog) {
            is ActiveDialog.AddExpense -> {
                AddExpenseDialog(
                    categories = state.activeCategories,
                    useBengaliDigits = state.useBengaliDigits,
                    onDismiss = { viewModel.dismissDialog() },
                    onSubmit = { amount, catId, src, desc, note, nec, ts ->
                        viewModel.recordDiaryEntry(
                            type = DiaryEntryType.EXPENSE,
                            amountPaisa = amount,
                            categoryId = catId,
                            sourceDescription = src,
                            description = desc,
                            notes = note,
                            necessity = nec,
                            occurrenceDateEpochMs = ts
                        )
                    },
                    onCreateCategory = { name ->
                        viewModel.createCategory(name, isIncome = false)
                    }
                )
            }

            is ActiveDialog.AddIncome -> {
                AddIncomeDialog(
                    categories = state.activeCategories,
                    useBengaliDigits = state.useBengaliDigits,
                    onDismiss = { viewModel.dismissDialog() },
                    onSubmit = { amount, catId, src, desc, note, ts ->
                        viewModel.recordDiaryEntry(
                            type = DiaryEntryType.INCOME,
                            amountPaisa = amount,
                            categoryId = catId,
                            sourceDescription = src,
                            description = desc,
                            notes = note,
                            occurrenceDateEpochMs = ts
                        )
                    },
                    onCreateCategory = { name ->
                        viewModel.createCategory(name, isIncome = true)
                    }
                )
            }

            is ActiveDialog.EntryDetail -> {
                EntryDetailDialog(
                    entry = active.entry,
                    useBengaliDigits = state.useBengaliDigits,
                    onDismiss = { viewModel.dismissDialog() },
                    onDelete = { id -> viewModel.deleteDiaryEntry(id) }
                )
            }

            is ActiveDialog.AddFrugalityGoal -> {
                AddFrugalityGoalDialog(
                    categories = state.activeCategories,
                    onDismiss = { viewModel.dismissDialog() },
                    onSubmit = { title, goalType, catId, amount, period, note ->
                        viewModel.addFrugalityGoal(title, goalType, catId, amount, period, note)
                    }
                )
            }

            is ActiveDialog.ManageCategories -> {
                ManageCategoriesDialog(
                    categories = state.activeCategories,
                    onDismiss = { viewModel.dismissDialog() },
                    onCreateCategory = { name, isIncome, iconName ->
                        viewModel.createCategory(name, iconName = iconName, isIncome = isIncome)
                    },
                    onArchiveCategory = { id, isArchived ->
                        viewModel.archiveCategory(id, isArchived)
                    }
                )
            }

            is ActiveDialog.ReminderSettings -> {
                ReminderSettingsDialog(
                    isDailyEnabled = state.isDailyReminderEnabled,
                    onDismiss = { viewModel.dismissDialog() },
                    onUpdateSetting = { k, v -> viewModel.updateSetting(k, v) }
                )
            }

            is ActiveDialog.CrashRecovery -> {
                CrashRecoveryDialog(
                    onDismiss = { viewModel.dismissDialog() },
                    onDelete = { file -> viewModel.deleteCrashReport(file) }
                )
            }

            is ActiveDialog.Diagnostics -> {
                DiagnosticsDialog(
                    onDismiss = { viewModel.dismissDialog() }
                )
            }

            else -> { /* None */ }
        }
    }
}
