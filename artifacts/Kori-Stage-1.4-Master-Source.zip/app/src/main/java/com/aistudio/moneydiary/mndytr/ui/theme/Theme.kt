package com.aistudio.moneydiary.mndytr.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DarkKoriPrimary,
    onPrimary = DarkKoriBackground,
    primaryContainer = DarkKoriPrimarySoft,
    onPrimaryContainer = DarkKoriTextPrimary,
    secondary = DarkKoriInsight,
    onSecondary = DarkKoriBackground,
    secondaryContainer = DarkKoriRaisedSurface,
    onSecondaryContainer = DarkKoriTextPrimary,
    tertiary = DarkKoriWarning,
    background = DarkKoriBackground,
    surface = DarkKoriSurface,
    surfaceVariant = DarkKoriRaisedSurface,
    onBackground = DarkKoriTextPrimary,
    onSurface = DarkKoriTextPrimary,
    onSurfaceVariant = DarkKoriTextSecondary,
    outline = DarkKoriBorder
)

private val LightColorScheme = lightColorScheme(
    primary = LightKoriPrimary,
    onPrimary = LightKoriSurface,
    primaryContainer = LightKoriPrimarySoft,
    onPrimaryContainer = LightKoriTextPrimary,
    secondary = LightKoriInsight,
    onSecondary = LightKoriSurface,
    secondaryContainer = LightKoriPrimarySoft,
    onSecondaryContainer = LightKoriTextPrimary,
    tertiary = LightKoriWarning,
    background = LightKoriBackground,
    surface = LightKoriSurface,
    surfaceVariant = LightKoriPrimarySoft,
    onBackground = LightKoriTextPrimary,
    onSurface = LightKoriTextPrimary,
    onSurfaceVariant = LightKoriTextSecondary,
    outline = LightKoriBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve authoritative calm Bengali brand palette
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
