package com.aistudio.moneydiary.mndytr.data.local

import com.aistudio.moneydiary.mndytr.data.local.database.AppDatabase
import com.aistudio.moneydiary.mndytr.data.local.entity.AccountEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.CategoryEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.FrequentShortcutEntity
import com.aistudio.moneydiary.mndytr.domain.model.AccountType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

object DatabaseInitializer {

    suspend fun seedCategoriesIfEmpty(db: AppDatabase) {
        val categoryDao = db.categoryDao()
        if (categoryDao.getAll().isEmpty()) {
            val defaultCategories = listOf(
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "চা ও ধূমপান",
                    nameEn = "Tea & Cigarette",
                    iconName = "local_cafe",
                    colorHex = "#795548",
                    isMicroExpense = true,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 1
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "রিকশা ও যাতায়াত",
                    nameEn = "Rickshaw & Commute",
                    iconName = "directions_bike",
                    colorHex = "#FF9800",
                    isMicroExpense = true,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 2
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "খাবার ও নাস্তা",
                    nameEn = "Food & Snacks",
                    iconName = "restaurant",
                    colorHex = "#E91E63",
                    isMicroExpense = true,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 3
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "মোবাইল রিচার্জ ও নেট",
                    nameEn = "Mobile & Net",
                    iconName = "phone_android",
                    colorHex = "#00BCD4",
                    isMicroExpense = true,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 4
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "দৈনন্দিন বাজার",
                    nameEn = "Daily Groceries",
                    iconName = "shopping_cart",
                    colorHex = "#4CAF50",
                    isMicroExpense = false,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 5
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "ইউটিলিটি ও বিল",
                    nameEn = "Utilities & Bills",
                    iconName = "receipt",
                    colorHex = "#607D8B",
                    isMicroExpense = false,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 6
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "চিকিৎসা ও ঔষধ",
                    nameEn = "Medical & Health",
                    iconName = "local_hospital",
                    colorHex = "#F44336",
                    isMicroExpense = false,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 7
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "শিক্ষা ও বইপত্র",
                    nameEn = "Education & Books",
                    iconName = "menu_book",
                    colorHex = "#3F51B5",
                    isMicroExpense = false,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 8
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "দান ও সদকা",
                    nameEn = "Charity & Gift",
                    iconName = "volunteer_activism",
                    colorHex = "#009688",
                    isMicroExpense = false,
                    isIncomeCategory = false,
                    isSystemDefault = true,
                    displayOrder = 9
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "অনলাইন কাজের পারিশ্রমিক",
                    nameEn = "Freelance & Online Work",
                    iconName = "laptop_mac",
                    colorHex = "#2E7D32",
                    isMicroExpense = false,
                    isIncomeCategory = true,
                    isSystemDefault = true,
                    displayOrder = 10
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "বেতন ও সম্মানী",
                    nameEn = "Salary & Honorarium",
                    iconName = "payments",
                    colorHex = "#1B5E20",
                    isMicroExpense = false,
                    isIncomeCategory = true,
                    isSystemDefault = true,
                    displayOrder = 11
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "ব্যবসায়িক লাভ",
                    nameEn = "Business Profit",
                    iconName = "trending_up",
                    colorHex = "#43A047",
                    isMicroExpense = false,
                    isIncomeCategory = true,
                    isSystemDefault = true,
                    displayOrder = 12
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "উপহার বা বোনাস",
                    nameEn = "Gift or Bonus",
                    iconName = "card_giftcard",
                    colorHex = "#66BB6A",
                    isMicroExpense = false,
                    isIncomeCategory = true,
                    isSystemDefault = true,
                    displayOrder = 13
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "ঋণ বা হাওলাত গ্রহণ",
                    nameEn = "Borrowed Money",
                    iconName = "money",
                    colorHex = "#FFA000",
                    isMicroExpense = false,
                    isIncomeCategory = true,
                    isSystemDefault = true,
                    displayOrder = 14
                ),
                CategoryEntity(
                    id = UUID.randomUUID().toString(),
                    nameBn = "অন্যান্য সাধারণ আয়",
                    nameEn = "Other Income",
                    iconName = "attach_money",
                    colorHex = "#388E3C",
                    isMicroExpense = false,
                    isIncomeCategory = true,
                    isSystemDefault = true,
                    displayOrder = 15
                )
            )
            categoryDao.insertAll(defaultCategories)
        }
    }

    suspend fun seedShortcutsIfEmpty(db: AppDatabase, targetCashAccountId: String) {
        val categoryDao = db.categoryDao()
        val shortcutDao = db.frequentShortcutDao()

        if (shortcutDao.getAll().isEmpty()) {
            val allCats = categoryDao.getAll()
            val teaCat = allCats.firstOrNull { it.nameBn.contains("চা") } ?: allCats.firstOrNull { !it.isIncomeCategory }
            val rickshawCat = allCats.firstOrNull { it.nameBn.contains("রিকশা") } ?: teaCat
            val foodCat = allCats.firstOrNull { it.nameBn.contains("খাবার") } ?: teaCat
            val rechargeCat = allCats.firstOrNull { it.nameBn.contains("রিচার্জ") } ?: teaCat

            if (teaCat != null && rickshawCat != null && foodCat != null) {
                val defaultShortcuts = listOf(
                    FrequentShortcutEntity(
                        labelBn = "চা",
                        defaultAmountPaisa = 1000L, // ৳১০
                        defaultCategoryId = teaCat.id,
                        defaultAccountId = targetCashAccountId,
                        iconName = "local_cafe",
                        displayOrder = 1
                    ),
                    FrequentShortcutEntity(
                        labelBn = "সিগারেট",
                        defaultAmountPaisa = 2000L, // ৳২০
                        defaultCategoryId = teaCat.id,
                        defaultAccountId = targetCashAccountId,
                        iconName = "smoking_rooms",
                        displayOrder = 2
                    ),
                    FrequentShortcutEntity(
                        labelBn = "রিকশা ভাড়া",
                        defaultAmountPaisa = 3000L, // ৳৩০
                        defaultCategoryId = rickshawCat.id,
                        defaultAccountId = targetCashAccountId,
                        iconName = "directions_bike",
                        displayOrder = 3
                    ),
                    FrequentShortcutEntity(
                        labelBn = "সকালের নাস্তা",
                        defaultAmountPaisa = 5000L, // ৳৫০
                        defaultCategoryId = foodCat.id,
                        defaultAccountId = targetCashAccountId,
                        iconName = "restaurant",
                        displayOrder = 4
                    ),
                    FrequentShortcutEntity(
                        labelBn = "মোবাইল রিচার্জ",
                        defaultAmountPaisa = 10000L, // ৳১০০
                        defaultCategoryId = rechargeCat?.id ?: foodCat.id,
                        defaultAccountId = targetCashAccountId,
                        iconName = "phone_android",
                        displayOrder = 5
                    )
                )
                shortcutDao.insertAll(defaultShortcuts)
            }
        }
    }

    suspend fun seedDefaultsIfEmpty(
        db: AppDatabase,
        dispatcher: kotlinx.coroutines.CoroutineDispatcher = Dispatchers.IO
    ) = withContext(dispatcher) {
        val accountDao = db.accountDao()

        // 1. Seed Accounts if empty
        var cashAccount = accountDao.getAllActive().firstOrNull { it.type == AccountType.CASH.name }
        if (accountDao.getAllActive().isEmpty()) {
            val defaultAccounts = listOf(
                AccountEntity(
                    id = UUID.randomUUID().toString(),
                    name = "হাতে নগদ (ক্যাশ)",
                    type = AccountType.CASH.name,
                    currency = "BDT",
                    initialBalancePaisa = 0L,
                    colorHex = "#1B5E20",
                    iconName = "account_balance_wallet",
                    displayOrder = 1
                ),
                AccountEntity(
                    id = UUID.randomUUID().toString(),
                    name = "বিকাশ (bKash)",
                    type = AccountType.MFS_BKASH.name,
                    currency = "BDT",
                    initialBalancePaisa = 0L,
                    colorHex = "#D12053",
                    iconName = "smartphone",
                    displayOrder = 2
                ),
                AccountEntity(
                    id = UUID.randomUUID().toString(),
                    name = "নগদ (Nagad)",
                    type = AccountType.MFS_NAGAD.name,
                    currency = "BDT",
                    initialBalancePaisa = 0L,
                    colorHex = "#E63946",
                    iconName = "smartphone",
                    displayOrder = 3
                ),
                AccountEntity(
                    id = UUID.randomUUID().toString(),
                    name = "ব্যাংক অ্যাকাউন্ট",
                    type = AccountType.BANK.name,
                    currency = "BDT",
                    initialBalancePaisa = 0L,
                    colorHex = "#0288D1",
                    iconName = "account_balance",
                    displayOrder = 4
                )
            )
            for (acc in defaultAccounts) {
                accountDao.insert(acc)
            }
            cashAccount = defaultAccounts[0]
        }

        // 2. Seed Categories
        seedCategoriesIfEmpty(db)

        // 3. Seed Shortcuts
        if (cashAccount != null) {
            seedShortcutsIfEmpty(db, cashAccount.id)
        }
    }
}
