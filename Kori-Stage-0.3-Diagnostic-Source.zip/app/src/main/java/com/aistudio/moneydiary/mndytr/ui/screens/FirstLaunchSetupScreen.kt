package com.aistudio.moneydiary.mndytr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.moneydiary.mndytr.ui.components.BengaliNumberTextField
import com.aistudio.moneydiary.mndytr.ui.theme.IncomeGreen
import com.aistudio.moneydiary.mndytr.ui.theme.PrimaryEmerald
import com.aistudio.moneydiary.mndytr.ui.theme.SecondaryGold
import com.aistudio.moneydiary.mndytr.ui.util.BengaliFormatter
import java.util.UUID

data class SetupAccountDraft(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val type: String,
    var isEnabled: Boolean = true,
    var openingBalanceText: String = "0",
    val isCustom: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirstLaunchSetupScreen(
    onCompleteSetup: (
        useBengaliDigits: Boolean,
        accounts: List<SetupAccountDraft>
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    // Current step index (0 to 8: 9 steps total)
    var currentStep by remember { mutableStateOf(0) }
    var useBengaliLanguage by remember { mutableStateOf(true) }
    var useBengaliDigits by remember { mutableStateOf(true) }

    val accountDrafts = remember {
        mutableStateListOf(
            SetupAccountDraft(name = "নগদ", type = "CASH", isEnabled = true),
            SetupAccountDraft(name = "bKash", type = "MFS_BKASH", isEnabled = true),
            SetupAccountDraft(name = "Nagad", type = "MFS_NAGAD", isEnabled = true),
            SetupAccountDraft(name = "ব্যাংক", type = "BANK", isEnabled = true),
            SetupAccountDraft(name = "সঞ্চয়", type = "SAVINGS", isEnabled = true)
        )
    }

    var customAccountName by remember { mutableStateOf("") }
    var customAccountType by remember { mutableStateOf("BANK") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val steps = listOf(
        "স্বাগতম (Welcome)",
        "ভাষা নির্বাচন (Language)",
        "সংখ্যা পদ্ধতি (Numerals)",
        "ডিফল্ট হিসাব নির্বাচন (Accounts)",
        "কাস্টম হিসাব যোগ (Custom Account)",
        "প্রারম্ভিক স্থিতি (Opening Balance)",
        "তারিখ ও সময় (Date)",
        "পর্যালোচনা (Review)",
        "সেটআপ সমাপ্তি (Finish)"
    )

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("first_launch_setup_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ধাপ ${BengaliFormatter.formatNumber(currentStep + 1, useBengaliDigits)} / ${BengaliFormatter.formatNumber(steps.size, useBengaliDigits)}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryEmerald
                )
                Text(
                    text = steps[currentStep],
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step Content
            when (currentStep) {
                0 -> {
                    // Step 1: Welcome
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(PrimaryEmerald.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "Wallet",
                            tint = PrimaryEmerald,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "কড়ি",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "প্রতিটি কড়ির নির্ভুল হিসাব",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = SecondaryGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "আপনার প্রতিটি ছোট-বড় আয়, ব্যয়, কাজের অগ্রিম এবং সঞ্চয়ের হিসাব সম্পূর্ণ ব্যক্তিগতভাবে সংরক্ষণ করুন।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "🔒 ১০০% অফলাইন ও ব্যক্তিগত", fontWeight = FontWeight.Bold, color = PrimaryEmerald)
                            Text(text = "আপনার আর্থিক তথ্য ক্লাউড বা সার্ভারে পাঠানো হয় না। সবকিছু শুধু আপনার ফোনেই সুরক্ষিত।", fontSize = 13.sp)
                        }
                    }
                }

                1 -> {
                    // Step 2: Language Selection
                    Text(
                        text = "ভাষা নির্বাচন করুন",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FilterChip(
                            selected = useBengaliLanguage,
                            onClick = { useBengaliLanguage = true },
                            label = { Text("বাংলা (Bengali - Default)") },
                            modifier = Modifier.weight(1f).testTag("lang_bn_chip")
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "অ্যাপটি মূলত বাংলা ভাষাবাসীদের আর্থিক অভ্যাসের সাথে মিল রেখে তৈরি করা হয়েছে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                2 -> {
                    // Step 3: Numeral-system Selection
                    Text(
                        text = "টাকার অঙ্কের সংখ্যা পদ্ধতি",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FilterChip(
                            selected = useBengaliDigits,
                            onClick = { useBengaliDigits = true },
                            label = { Text("বাংলা সংখ্যা (৳ ১,২৫০)") },
                            modifier = Modifier.weight(1f).testTag("digits_bn_chip")
                        )
                        FilterChip(
                            selected = !useBengaliDigits,
                            onClick = { useBengaliDigits = false },
                            label = { Text("English Digits (৳ 1,250)") },
                            modifier = Modifier.weight(1f).testTag("digits_en_chip")
                        )
                    }
                }

                3 -> {
                    // Step 4: Default Account Selection (Enable/Disable/Rename)
                    Text(
                        text = "প্রাথমিক হিসাবসমূহ সক্রিয় করুন",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "যে হিসাবগুলো ব্যবহার করতে চান সেগুলো টিক দিয়ে রাখুন এবং প্রয়োজনমতো নাম পরিবর্তন করুন।",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    accountDrafts.forEachIndexed { index, draft ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (draft.isEnabled) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = draft.isEnabled,
                                    onCheckedChange = { isChecked ->
                                        accountDrafts[index] = draft.copy(isEnabled = isChecked)
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                OutlinedTextField(
                                    value = draft.name,
                                    onValueChange = { newName ->
                                        accountDrafts[index] = draft.copy(name = newName)
                                    },
                                    label = { Text("হিসাবের নাম") },
                                    modifier = Modifier.weight(1f),
                                    enabled = draft.isEnabled,
                                    singleLine = true
                                )
                            }
                        }
                    }
                }

                4 -> {
                    // Step 5: Custom Account Creation
                    Text(
                        text = "নতুন কাস্টম হিসাব যোগ (ঐচ্ছিক)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = customAccountName,
                        onValueChange = { customAccountName = it },
                        label = { Text("কাস্টম হিসাবের নাম (যেমন: উপায়, রকেট, অন্য ব্যাংক)") },
                        modifier = Modifier.fillMaxWidth().testTag("custom_account_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("BANK" to "ব্যাংক", "MFS_OTHER" to "মোবাইল ওয়ালেট", "CASH" to "ক্যাশ", "SAVINGS" to "সঞ্চয়").forEach { (typeKey, typeLabel) ->
                            FilterChip(
                                selected = customAccountType == typeKey,
                                onClick = { customAccountType = typeKey },
                                label = { Text(typeLabel) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = {
                            if (customAccountName.isNotBlank()) {
                                accountDrafts.add(
                                    SetupAccountDraft(
                                        name = customAccountName.trim(),
                                        type = customAccountType,
                                        isEnabled = true,
                                        isCustom = true
                                    )
                                )
                                customAccountName = ""
                            }
                        },
                        enabled = customAccountName.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().testTag("add_custom_account_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("তালিকায় যোগ করুন")
                    }
                }

                5 -> {
                    // Step 6: Opening Balance Entry
                    Text(
                        text = "হিসাবের বর্তমান শুরুর স্থিতি (Opening Balance)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "প্রতিটি হিসাবে এখন কত টাকা রয়েছে তা লিখুন। এটি আয় বা ব্যয় হিসেবে গণনা হবে না।",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    accountDrafts.filter { it.isEnabled }.forEachIndexed { index, draft ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = draft.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.width(100.dp)
                            )
                            BengaliNumberTextField(
                                value = draft.openingBalanceText,
                                onValueChange = { newVal ->
                                    val idx = accountDrafts.indexOfFirst { it.id == draft.id }
                                    if (idx != -1) {
                                        accountDrafts[idx] = draft.copy(openingBalanceText = newVal)
                                    }
                                },
                                label = "শুরুর টাকা (৳)",
                                modifier = Modifier.weight(1f),
                                testTag = "opening_bal_${draft.type}"
                            )
                        }
                    }
                }

                6 -> {
                    // Step 7: Opening Date Selection
                    Text(
                        text = "হিসাব শুরুর তারিখ",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "আজকের তারিখ থেকে কার্যকর", fontWeight = FontWeight.Bold, color = PrimaryEmerald)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = BengaliFormatter.formatDate(System.currentTimeMillis(), useBengaliDigits),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }

                7 -> {
                    // Step 8: Review
                    Text(
                        text = "সেটআপ পর্যালোচনা",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val activeDrafts = accountDrafts.filter { it.isEnabled }
                    val totalOpeningPaisa = activeDrafts.fold(0L) { acc, draft -> acc + BengaliFormatter.parseAmountToPaisa(draft.openingBalanceText) }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "সক্রিয় হিসাবসমূহ:", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            activeDrafts.forEach { draft ->
                                val paisa = BengaliFormatter.parseAmountToPaisa(draft.openingBalanceText)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "• ${draft.name} (${draft.type})")
                                    Text(text = BengaliFormatter.formatPaisa(paisa, useBengaliDigits))
                                }
                            }
                            androidx.compose.material3.HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "মোট শুরুর স্থিতি:", fontWeight = FontWeight.Bold)
                                Text(
                                    text = BengaliFormatter.formatPaisa(totalOpeningPaisa, useBengaliDigits),
                                    fontWeight = FontWeight.Bold,
                                    color = IncomeGreen
                                )
                            }
                        }
                    }
                }

                8 -> {
                    // Step 9: Completion
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(IncomeGreen.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = IncomeGreen,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "সেটআপ সম্পন্ন হয়েছে!",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryEmerald
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "এখন থেকে আপনি সহজেই আপনার প্রতিটি টাকা লেনদেনের নির্ভুল হিসাব রাখতে পারবেন।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            validationError?.let { err ->
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Navigation Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (currentStep > 0) {
                    TextButton(
                        onClick = {
                            validationError = null
                            currentStep--
                        },
                        modifier = Modifier.testTag("setup_back_button")
                    ) {
                        Text("পেছনে")
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (currentStep < steps.size - 1) {
                    Button(
                        onClick = {
                            // Validation checks
                            val activeDrafts = accountDrafts.filter { it.isEnabled }
                            if (currentStep == 3 && activeDrafts.isEmpty()) {
                                validationError = "অন্তত একটি হিসাব সক্রিয় রাখতে হবে!"
                                return@Button
                            }
                            validationError = null
                            currentStep++
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.testTag("setup_next_button")
                    ) {
                        Text(if (currentStep == 0) "সেটআপ শুরু করুন" else "পরবর্তী ধাপ")
                    }
                } else {
                    Button(
                        onClick = {
                            val activeDrafts = accountDrafts.filter { it.isEnabled }
                            if (activeDrafts.isEmpty()) {
                                validationError = "অন্তত একটি হিসাব সক্রিয় রাখতে হবে!"
                                return@Button
                            }
                            onCompleteSetup(useBengaliDigits, activeDrafts)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.testTag("setup_finish_button")
                    ) {
                        Text("ড্যাশবোর্ডে প্রবেশ করুন")
                    }
                }
            }
        }
    }
}
