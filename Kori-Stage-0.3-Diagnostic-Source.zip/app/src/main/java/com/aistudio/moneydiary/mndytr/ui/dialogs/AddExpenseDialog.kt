package com.aistudio.moneydiary.mndytr.ui.dialogs

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aistudio.moneydiary.mndytr.data.local.entity.AccountEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.CategoryEntity
import com.aistudio.moneydiary.mndytr.ui.components.BengaliAmountField
import com.aistudio.moneydiary.mndytr.ui.theme.ExpenseRed
import com.aistudio.moneydiary.mndytr.ui.util.BengaliFormatter

@Composable
fun AddExpenseDialog(
    categories: List<CategoryEntity>,
    accounts: List<AccountEntity>,
    useBengaliDigits: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (accountId: String, amountPaisa: Long, categoryId: String, description: String, notes: String?, isDraft: Boolean) -> Unit
) {
    val expenseCategories = remember(categories) {
        categories.filter { !it.isIncomeCategory }
    }

    var amountInput by remember { mutableStateOf("") }
    var selectedCategoryId by remember {
        mutableStateOf(expenseCategories.firstOrNull()?.id ?: "")
    }
    var selectedAccountId by remember {
        mutableStateOf(accounts.firstOrNull()?.id ?: "")
    }
    var description by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var isDraft by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "নতুন খরচ লিখুন",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BengaliAmountField(
                    value = amountInput,
                    onValueChange = {
                        amountInput = it
                        errorMessage = null
                    },
                    useBengaliDigits = useBengaliDigits,
                    quickAmounts = listOf(10L, 20L, 50L, 100L, 500L)
                )

                // Category Chips
                Text(
                    text = "খরচের খাত / ক্যাটাগরি",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    expenseCategories.forEach { category ->
                        FilterChip(
                            selected = selectedCategoryId == category.id,
                            onClick = { selectedCategoryId = category.id },
                            label = { Text(category.nameBn) }
                        )
                    }
                }

                // Account Selection
                Text(
                    text = "টাকা কোথা থেকে যাচ্ছে?",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    accounts.forEach { account ->
                        FilterChip(
                            selected = selectedAccountId == account.id,
                            onClick = { selectedAccountId = account.id },
                            label = { Text(account.name) }
                        )
                    }
                }

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("বিবরণ (ঐচ্ছিক)") },
                    placeholder = {
                        val catName = expenseCategories.find { it.id == selectedCategoryId }?.nameBn ?: "খরচ"
                        Text(catName)
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("অতিরিক্ত মন্তব্য / নোট") },
                    singleLine = false,
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                // Draft Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "খসড়া হিসেবে রাখুন (পরে নিশ্চিত করবেন)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Switch(
                        checked = isDraft,
                        onCheckedChange = { isDraft = it }
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedPaisa = BengaliFormatter.parseAmountToPaisa(amountInput)
                    if (parsedPaisa <= 0L) {
                        errorMessage = "সঠিক পরিমাণ টাকা লিখুন"
                        return@Button
                    }
                    if (selectedAccountId.isBlank()) {
                        errorMessage = "অ্যাকাউন্ট নির্বাচন করুন"
                        return@Button
                    }
                    if (selectedCategoryId.isBlank()) {
                        errorMessage = "ক্যাটাগরি নির্বাচন করুন"
                        return@Button
                    }

                    val cat = expenseCategories.find { it.id == selectedCategoryId }
                    val finalDesc = description.ifBlank { cat?.nameBn ?: "দৈনন্দিন খরচ" }
                    val finalNotes = notes.ifBlank { null }

                    onConfirm(selectedAccountId, parsedPaisa, selectedCategoryId, finalDesc, finalNotes, isDraft)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                modifier = Modifier.testTag("confirm_expense_button")
            ) {
                Text(if (isDraft) "খসড়া সংরক্ষণ" else "খরচ নিশ্চিত করুন")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        },
        shape = RoundedCornerShape(16.dp)
    )
}
