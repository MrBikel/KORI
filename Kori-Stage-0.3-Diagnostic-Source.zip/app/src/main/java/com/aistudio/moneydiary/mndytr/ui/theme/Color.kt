package com.aistudio.moneydiary.mndytr.ui.theme

import androidx.compose.ui.graphics.Color

// Semantic Brand Colours (Deep Emerald / Bengali Financial Trust)
val PrimaryEmerald = Color(0xFF0E4D36)
val OnPrimaryEmerald = Color(0xFFFFFFFF)
val PrimaryContainerEmerald = Color(0xFFC4EED0)
val OnPrimaryContainerEmerald = Color(0xFF002114)

val SecondaryGold = Color(0xFFC59B27)
val OnSecondaryGold = Color(0xFFFFFFFF)
val SecondaryContainerGold = Color(0xFFFFF0C2)
val OnSecondaryContainerGold = Color(0xFF261A00)

val TertiaryTeal = Color(0xFF006A60)
val TertiaryContainerTeal = Color(0xFF70F7E6)

// Financial Semantic Status Colors
val IncomeGreen = Color(0xFF2E7D32)
val IncomeGreenContainer = Color(0xFFE8F5E9)
val ExpenseRed = Color(0xFFC62828)
val ExpenseRedContainer = Color(0xFFFFEBEE)
val AdvanceAmber = Color(0xFFEF6C00)
val AdvanceAmberContainer = Color(0xFFFFF3E0)
val ReceivableBlue = Color(0xFF1565C0)
val ReceivableBlueContainer = Color(0xFFE3F2FD)
val PayableOrange = Color(0xFFD84315)
val PayableOrangeContainer = Color(0xFFFBE9E7)
val TransferTeal = Color(0xFF00897B)
val TransferTealContainer = Color(0xFFE0F2F1)

// Neutral Backgrounds & Surfaces
val LightBackground = Color(0xFFF7FAF7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE5EDE7)
val OnLightSurface = Color(0xFF181D1A)
val OnLightSurfaceVariant = Color(0xFF414944)
val LightOutline = Color(0xFF717974)

val DarkBackground = Color(0xFF111513)
val DarkSurface = Color(0xFF181D1A)
val DarkSurfaceVariant = Color(0xFF232A26)
val OnDarkSurface = Color(0xFFE1E5E2)
val OnDarkSurfaceVariant = Color(0xFFBFC6C1)
val DarkOutline = Color(0xFF8B938D)
