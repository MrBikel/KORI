package com.aistudio.moneydiary.mndytr.ui.dialogs

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aistudio.moneydiary.mndytr.data.local.entity.AccountEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.CategoryEntity
import com.aistudio.moneydiary.mndytr.ui.components.BengaliAmountField
import com.aistudio.moneydiary.mndytr.ui.theme.IncomeGreen
import com.aistudio.moneydiary.mndytr.ui.util.BengaliFormatter

@Composable
fun AddIncomeDialog(
    categories: List<CategoryEntity>,
    accounts: List<AccountEntity>,
    useBengaliDigits: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (accountId: String, amountPaisa: Long, categoryId: String?, personId: String?, description: String, notes: String?) -> Unit
) {
    val incomeCategories = remember(categories) {
        categories.filter { it.isIncomeCategory }
    }

    var amountInput by remember { mutableStateOf("") }
    var selectedCategoryId by remember {
        mutableStateOf(incomeCategories.firstOrNull()?.id ?: "")
    }
    var selectedAccountId by remember {
        mutableStateOf(accounts.firstOrNull()?.id ?: "")
    }
    var description by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "সরাসরি আয় লিখুন",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BengaliAmountField(
                    value = amountInput,
                    onValueChange = {
                        amountInput = it
                        errorMessage = null
                    },
                    label = "আয়ের পরিমাণ",
                    useBengaliDigits = useBengaliDigits,
                    quickAmounts = listOf(100L, 500L, 1000L, 5000L, 10000L)
                )

                // Category Chips
                Text(
                    text = "আয়ের উৎস / খাত",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    incomeCategories.forEach { category ->
                        FilterChip(
                            selected = selectedCategoryId == category.id,
                            onClick = { selectedCategoryId = category.id },
                            label = { Text(category.nameBn) }
                        )
                    }
                }

                // Account Selection
                Text(
                    text = "কোন অ্যাকাউন্টে টাকা জমা হচ্ছে?",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    accounts.forEach { account ->
                        FilterChip(
                            selected = selectedAccountId == account.id,
                            onClick = { selectedAccountId = account.id },
                            label = { Text(account.name) }
                        )
                    }
                }

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("বিবরণ") },
                    placeholder = {
                        val catName = incomeCategories.find { it.id == selectedCategoryId }?.nameBn ?: "আয়"
                        Text(catName)
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("মন্তব্য / নোট (ঐচ্ছিক)") },
                    singleLine = false,
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedPaisa = BengaliFormatter.parseAmountToPaisa(amountInput)
                    if (parsedPaisa <= 0L) {
                        errorMessage = "সঠিক পরিমাণ টাকা লিখুন"
                        return@Button
                    }
                    if (selectedAccountId.isBlank()) {
                        errorMessage = "অ্যাকাউন্ট নির্বাচন করুন"
                        return@Button
                    }

                    val cat = incomeCategories.find { it.id == selectedCategoryId }
                    val finalDesc = description.ifBlank { cat?.nameBn ?: "সরাসরি আয়" }
                    val finalNotes = notes.ifBlank { null }

                    onConfirm(selectedAccountId, parsedPaisa, selectedCategoryId.ifBlank { null }, null, finalDesc, finalNotes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen),
                modifier = Modifier.testTag("confirm_income_button")
            ) {
                Text("আয় নিশ্চিত করুন")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        },
        shape = RoundedCornerShape(16.dp)
    )
}
