package com.aistudio.moneydiary.mndytr.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.aistudio.moneydiary.mndytr.data.local.dao.AccountDao
import com.aistudio.moneydiary.mndytr.data.local.dao.AppSettingDao
import com.aistudio.moneydiary.mndytr.data.local.dao.AttachmentDao
import com.aistudio.moneydiary.mndytr.data.local.dao.AuditDao
import com.aistudio.moneydiary.mndytr.data.local.dao.BackupJobDao
import com.aistudio.moneydiary.mndytr.data.local.dao.BackupMetadataDao
import com.aistudio.moneydiary.mndytr.data.local.dao.CategoryDao
import com.aistudio.moneydiary.mndytr.data.local.dao.FrequentShortcutDao
import com.aistudio.moneydiary.mndytr.data.local.dao.LedgerEventDao
import com.aistudio.moneydiary.mndytr.data.local.dao.PayableDao
import com.aistudio.moneydiary.mndytr.data.local.dao.PersonDao
import com.aistudio.moneydiary.mndytr.data.local.dao.ReceivableDao
import com.aistudio.moneydiary.mndytr.data.local.dao.SavingsGoalDao
import com.aistudio.moneydiary.mndytr.data.local.dao.WorkDao
import com.aistudio.moneydiary.mndytr.data.local.entity.AccountEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.AppSettingEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.AttachmentEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.AuditLogEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.BackupJobEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.BackupMetadataEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.CategoryEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.FrequentShortcutEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.PayableEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.PersonEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.ReceivableEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.SavingsGoalEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.TransactionEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.WorkRecordEntity

@Database(
    entities = [
        AccountEntity::class,
        CategoryEntity::class,
        PersonEntity::class,
        WorkRecordEntity::class,
        TransactionEntity::class,
        ReceivableEntity::class,
        PayableEntity::class,
        SavingsGoalEntity::class,
        FrequentShortcutEntity::class,
        AttachmentEntity::class,
        BackupJobEntity::class,
        BackupMetadataEntity::class,
        AppSettingEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun accountDao(): AccountDao
    abstract fun categoryDao(): CategoryDao
    abstract fun personDao(): PersonDao
    abstract fun workDao(): WorkDao
    abstract fun ledgerEventDao(): LedgerEventDao
    abstract fun receivableDao(): ReceivableDao
    abstract fun payableDao(): PayableDao
    abstract fun savingsGoalDao(): SavingsGoalDao
    abstract fun frequentShortcutDao(): FrequentShortcutDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun backupJobDao(): BackupJobDao
    abstract fun backupMetadataDao(): BackupMetadataDao
    abstract fun appSettingDao(): AppSettingDao
    abstract fun auditDao(): AuditDao

    companion object {
        const val DATABASE_NAME = "my_money_diary.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration(false)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
