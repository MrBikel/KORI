package com.aistudio.moneydiary.mndytr.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.aistudio.moneydiary.mndytr.data.local.DatabaseInitializer
import com.aistudio.moneydiary.mndytr.data.local.database.AppDatabase
import com.aistudio.moneydiary.mndytr.data.local.entity.AccountEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.AppSettingEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.FrequentShortcutEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.PersonEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.TransactionEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.WorkRecordEntity
import com.aistudio.moneydiary.mndytr.domain.model.ConfirmationStatus
import com.aistudio.moneydiary.mndytr.domain.model.LedgerEventCode
import com.aistudio.moneydiary.mndytr.domain.model.PaymentStatus
import com.aistudio.moneydiary.mndytr.domain.model.WorkStatus
import com.aistudio.moneydiary.mndytr.domain.service.DiagnosticService
import com.aistudio.moneydiary.mndytr.domain.service.FinancialCalculationEngine
import com.aistudio.moneydiary.mndytr.domain.service.FinancialResult
import com.aistudio.moneydiary.mndytr.domain.service.FinancialService
import com.aistudio.moneydiary.mndytr.ui.screens.SetupAccountDraft
import com.aistudio.moneydiary.mndytr.ui.state.AccountWithBalance
import com.aistudio.moneydiary.mndytr.ui.state.ActiveDialog
import com.aistudio.moneydiary.mndytr.ui.state.AppNavTab
import com.aistudio.moneydiary.mndytr.ui.state.DashboardSummary
import com.aistudio.moneydiary.mndytr.ui.state.DiaryUiState
import com.aistudio.moneydiary.mndytr.ui.state.TransactionDisplayItem
import com.aistudio.moneydiary.mndytr.ui.state.WorkDisplayItem
import com.aistudio.moneydiary.mndytr.ui.util.BengaliFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class DiaryViewModel(
    private val db: AppDatabase,
    private val financialService: FinancialService = FinancialService(db),
    private val ioDispatcher: kotlinx.coroutines.CoroutineDispatcher = Dispatchers.IO
) : ViewModel() {

    private val _uiState = MutableStateFlow(DiaryUiState())
    val uiState: StateFlow<DiaryUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch(ioDispatcher) {
            try {
                val isSetupDone = db.appSettingDao().get("is_setup_completed") == "true"
                if (isSetupDone) {
                    _uiState.update { it.copy(isSetupCompleted = true) }
                    loadDataInternal()
                } else {
                    val existingAccounts = db.accountDao().getAllActive()
                    if (existingAccounts.isNotEmpty()) {
                        db.appSettingDao().set(AppSettingEntity("is_setup_completed", "true"))
                        _uiState.update { it.copy(isSetupCompleted = true) }
                        loadDataInternal()
                    } else {
                        _uiState.update { it.copy(isLoading = false, isSetupCompleted = false) }
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, snackbarMessage = "ডাটাবেজ লোড করতে সমস্যা হয়েছে") }
            }
        }
    }

    fun completeFirstLaunchSetup(
        useBengaliDigits: Boolean,
        accounts: List<SetupAccountDraft>
    ) {
        viewModelScope.launch(ioDispatcher) {
            var success = false
            withContext(ioDispatcher) {
                try {
                    val accountDao = db.accountDao()
                    db.appSettingDao().set(AppSettingEntity("use_bengali_digits", useBengaliDigits.toString()))
                    DatabaseInitializer.seedCategoriesIfEmpty(db)

                    var firstCashAccountId: String? = null
                    accounts.filter { it.isEnabled }.forEach { draft ->
                        val colorHex = when (draft.type) {
                            "CASH" -> "#0E4D36"
                            "MFS_BKASH" -> "#E2136E"
                            "MFS_NAGAD" -> "#F7941D"
                            "BANK" -> "#1565C0"
                            "SAVINGS" -> "#2E7D32"
                            else -> "#455A64"
                        }
                        val account = AccountEntity(
                            name = draft.name.trim(),
                            type = draft.type,
                            colorHex = colorHex,
                            initialBalancePaisa = 0L
                        )
                        accountDao.insert(account)
                        if (draft.type == "CASH" && firstCashAccountId == null) {
                            firstCashAccountId = account.id
                        }

                        val openingPaisa = BengaliFormatter.parseAmountToPaisa(draft.openingBalanceText)
                        if (openingPaisa > 0L) {
                            financialService.createOpeningBalance(
                                accountId = account.id,
                                amountPaisa = openingPaisa,
                                description = "প্রারম্ভিক স্থিতি: ${account.name}"
                            )
                        }
                    }

                    val fallbackAcc = accountDao.getAllActive().firstOrNull()
                    val targetCashAccId = firstCashAccountId ?: fallbackAcc?.id
                    if (targetCashAccId != null) {
                        DatabaseInitializer.seedShortcutsIfEmpty(db, targetCashAccId)
                    }

                    db.appSettingDao().set(AppSettingEntity("is_setup_completed", "true"))
                    success = true
                } catch (e: Exception) {
                    _uiState.update { it.copy(snackbarMessage = "সেটআপ সফলভাবে সংরক্ষণ করা যায়নি। আবার চেষ্টা করুন।") }
                }
            }

            if (success) {
                _uiState.update {
                    it.copy(
                        isSetupCompleted = true,
                        useBengaliDigits = useBengaliDigits,
                        snackbarMessage = "সেটআপ সফলভাবে সম্পন্ন হয়েছে!"
                    )
                }
                loadDataInternal()
            }
        }
    }

    fun selectTab(tab: AppNavTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun toggleBengaliDigits() {
        val newVal = !_uiState.value.useBengaliDigits
        viewModelScope.launch(ioDispatcher) {
            try {
                db.appSettingDao().set(AppSettingEntity("use_bengali_digits", newVal.toString()))
                _uiState.update { it.copy(useBengaliDigits = newVal) }
            } catch (_: Exception) {}
        }
    }

    fun openDialog(dialog: ActiveDialog) {
        if (dialog != ActiveDialog.None) {
            DiagnosticService.addCheckpoint("FORM_OPENED", dialog.javaClass.simpleName)
        }
        _uiState.update { it.copy(activeDialog = dialog) }
    }

    fun dismissDialog() {
        _uiState.update { it.copy(activeDialog = ActiveDialog.None) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    fun deleteCrashReport(file: java.io.File) {
        DiagnosticService.deleteReport(file)
        dismissDialog()
    }

    fun addExpense(
        accountId: String,
        amountPaisa: Long,
        categoryId: String,
        description: String,
        notes: String? = null,
        isDraft: Boolean = false
    ) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "EXPENSE")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "EXPENSE")
                    if (isDraft) {
                        DiagnosticService.addCheckpoint("SAVING_DRAFT", "EXPENSE")
                        val cat = db.categoryDao().getById(categoryId.trim())
                        val draftEvent = TransactionEntity(
                            eventCode = LedgerEventCode.TX_02_EXPENSE.name,
                            eventKind = "CASH_EVENT",
                            amountPaisa = amountPaisa,
                            sourceAccountId = accountId.trim().takeIf { it.isNotBlank() },
                            categoryId = categoryId.trim().takeIf { it.isNotBlank() },
                            description = description.ifBlank { cat?.nameBn ?: "খরচ" },
                            notes = notes?.takeIf { it.isNotBlank() },
                            confirmationStatus = ConfirmationStatus.DRAFT.name
                        )
                        db.ledgerEventDao().insert(draftEvent)
                        _uiState.update {
                            it.copy(
                                lastAddedEventId = draftEvent.id,
                                snackbarMessage = "খসড়া খরচ সংরক্ষিত হয়েছে"
                            )
                        }
                        isSuccess = true
                        DiagnosticService.addCheckpoint("DRAFT_SAVED", "EXPENSE")
                    } else {
                        DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "EXPENSE")
                        val result = financialService.addExpense(
                            sourceAccountId = accountId,
                            amountPaisa = amountPaisa,
                            categoryId = categoryId,
                            description = description,
                            notes = notes
                        )
                        when (result) {
                            is FinancialResult.Success -> {
                                DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "EXPENSE")
                                _uiState.update {
                                    it.copy(
                                        lastAddedEventId = result.data.id,
                                        snackbarMessage = "খরচ যুক্ত হয়েছে: ${BengaliFormatter.formatPaisa(amountPaisa, it.useBengaliDigits)}"
                                    )
                                }
                                isSuccess = true
                            }
                            is FinancialResult.Error -> {
                                DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "EXPENSE")
                                _uiState.update { it.copy(snackbarMessage = "ত্রুটি: ${result.message}") }
                            }
                        }
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "EXPENSE")
                    _uiState.update { it.copy(snackbarMessage = "লেনদেনটি সংরক্ষণ করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "EXPENSE")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun addIncome(
        accountId: String,
        amountPaisa: Long,
        categoryId: String?,
        personId: String?,
        description: String,
        notes: String? = null
    ) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "INCOME")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "INCOME")
                    DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "INCOME")
                    val result = financialService.addDirectIncome(
                        destinationAccountId = accountId,
                        amountPaisa = amountPaisa,
                        categoryId = categoryId,
                        personId = personId,
                        description = description,
                        notes = notes
                    )
                    when (result) {
                        is FinancialResult.Success -> {
                            DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "INCOME")
                            _uiState.update {
                                it.copy(
                                    lastAddedEventId = result.data.id,
                                    snackbarMessage = "আয় যুক্ত হয়েছে: ${BengaliFormatter.formatPaisa(amountPaisa, it.useBengaliDigits)}"
                                )
                            }
                            isSuccess = true
                        }
                        is FinancialResult.Error -> {
                            DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "INCOME")
                            _uiState.update { it.copy(snackbarMessage = "ত্রুটি: ${result.message}") }
                        }
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "INCOME")
                    _uiState.update { it.copy(snackbarMessage = "লেনদেনটি সংরক্ষণ করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "INCOME")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun addWorkAdvance(
        clientName: String,
        workTitle: String,
        agreedTotalPaisa: Long,
        advanceReceivedPaisa: Long,
        destinationAccountId: String,
        notes: String? = null
    ) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "WORK_ADVANCE")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "WORK_ADVANCE")
                    val personDao = db.personDao()
                    val workDao = db.workDao()

                    var person = personDao.getAll().firstOrNull { it.name.trim().equals(clientName.trim(), ignoreCase = true) }
                    if (person == null) {
                        person = PersonEntity(
                            name = clientName.trim(),
                            personType = "CLIENT"
                        )
                        personDao.insert(person)
                    }

                    val work = WorkRecordEntity(
                        clientId = person.id,
                        title = workTitle.trim(),
                        agreedTotalPricePaisa = agreedTotalPaisa,
                        workStatus = WorkStatus.IN_PROGRESS.name,
                        paymentStatus = if (advanceReceivedPaisa > 0) PaymentStatus.ADVANCE_RECEIVED.name else PaymentStatus.UNPAID.name,
                        preferredAccountId = destinationAccountId.trim().takeIf { it.isNotBlank() },
                        notes = notes?.takeIf { it.isNotBlank() }
                    )
                    workDao.insert(work)

                    if (advanceReceivedPaisa > 0) {
                        DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "WORK_ADVANCE")
                        val result = financialService.receiveWorkAdvance(
                            workId = work.id,
                            destinationAccountId = destinationAccountId,
                            amountPaisa = advanceReceivedPaisa,
                            description = "কাজের অগ্রিম টোকেন: $workTitle"
                        )
                        when (result) {
                            is FinancialResult.Success -> {
                                DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "WORK_ADVANCE")
                                _uiState.update {
                                    it.copy(
                                        lastAddedEventId = result.data.id,
                                        snackbarMessage = "অগ্রিম দায় যুক্ত হয়েছে: ${BengaliFormatter.formatPaisa(advanceReceivedPaisa, it.useBengaliDigits)}"
                                    )
                                }
                                isSuccess = true
                            }
                            is FinancialResult.Error -> {
                                DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "WORK_ADVANCE")
                                _uiState.update { it.copy(snackbarMessage = "অগ্রিম এন্ট্রি ত্রুটি: ${result.message}") }
                            }
                        }
                    } else {
                        DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "WORK_ADVANCE_NO_PAYMENT")
                        _uiState.update { it.copy(snackbarMessage = "কাজের চুক্তি সংরক্ষিত হয়েছে") }
                        isSuccess = true
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "WORK_ADVANCE")
                    _uiState.update { it.copy(snackbarMessage = "লেনদেনটি সংরক্ষণ করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "WORK_ADVANCE")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun transferFunds(
        sourceAccountId: String,
        destinationAccountId: String,
        amountPaisa: Long,
        feePaisa: Long = 0L,
        description: String = "নিজস্ব অ্যাকাউন্টে স্থানান্তর"
    ) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "TRANSFER")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "TRANSFER")
                    DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "TRANSFER")
                    val result = financialService.transferBetweenAccounts(
                        sourceAccountId = sourceAccountId,
                        destinationAccountId = destinationAccountId,
                        amountPaisa = amountPaisa,
                        feePaisa = feePaisa,
                        description = description
                    )
                    when (result) {
                        is FinancialResult.Success -> {
                            DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "TRANSFER")
                            _uiState.update {
                                it.copy(
                                    lastAddedEventId = result.data.id,
                                    snackbarMessage = "স্থানান্তর সম্পন্ন হয়েছে: ${BengaliFormatter.formatPaisa(amountPaisa, it.useBengaliDigits)}"
                                )
                            }
                            isSuccess = true
                        }
                        is FinancialResult.Error -> {
                            DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "TRANSFER")
                            _uiState.update { it.copy(snackbarMessage = "ত্রুটি: ${result.message}") }
                        }
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "TRANSFER")
                    _uiState.update { it.copy(snackbarMessage = "লেনদেনটি সংরক্ষণ করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "TRANSFER")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun allocateSavings(
        sourceAccountId: String,
        destinationAccountId: String,
        amountPaisa: Long,
        note: String? = null
    ) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "SAVINGS_ALLOCATION")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "SAVINGS_ALLOCATION")
                    DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "SAVINGS_ALLOCATION")
                    val result = financialService.allocateSavings(
                        sourceAccountId = sourceAccountId,
                        savingsAccountId = destinationAccountId,
                        amountPaisa = amountPaisa,
                        description = note ?: "সঞ্চয়ে বরাদ্দ"
                    )
                    when (result) {
                        is FinancialResult.Success -> {
                            DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "SAVINGS_ALLOCATION")
                            _uiState.update {
                                it.copy(
                                    lastAddedEventId = result.data.id,
                                    snackbarMessage = "সঞ্চয়ে স্থানান্তর সম্পন্ন: ${BengaliFormatter.formatPaisa(amountPaisa, it.useBengaliDigits)}"
                                )
                            }
                            isSuccess = true
                        }
                        is FinancialResult.Error -> {
                            DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "SAVINGS_ALLOCATION")
                            _uiState.update { it.copy(snackbarMessage = "ত্রুটি: ${result.message}") }
                        }
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "SAVINGS_ALLOCATION")
                    _uiState.update { it.copy(snackbarMessage = "লেনদেনটি সংরক্ষণ করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "SAVINGS_ALLOCATION")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun setOpeningBalance(
        accountId: String,
        amountPaisa: Long,
        description: String = "হিসাবের প্রারম্ভিক স্থিতি"
    ) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "OPENING_BALANCE")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "OPENING_BALANCE")
                    DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "OPENING_BALANCE")
                    val result = financialService.createOpeningBalance(
                        accountId = accountId,
                        amountPaisa = amountPaisa,
                        description = description
                    )
                    when (result) {
                        is FinancialResult.Success -> {
                            DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "OPENING_BALANCE")
                            _uiState.update {
                                it.copy(
                                    lastAddedEventId = result.data.id,
                                    snackbarMessage = "প্রারম্ভিক স্থিতি নির্ধারিত: ${BengaliFormatter.formatPaisa(amountPaisa, it.useBengaliDigits)}"
                                )
                            }
                            isSuccess = true
                        }
                        is FinancialResult.Error -> {
                            DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "OPENING_BALANCE")
                            _uiState.update { it.copy(snackbarMessage = "ত্রুটি: ${result.message}") }
                        }
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "OPENING_BALANCE")
                    _uiState.update { it.copy(snackbarMessage = "লেনদেনটি সংরক্ষণ করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "OPENING_BALANCE")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun createAccount(
        name: String,
        type: String,
        colorHex: String,
        initialBalancePaisa: Long
    ) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "CREATE_ACCOUNT")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "CREATE_ACCOUNT")
                    val newAccount = AccountEntity(
                        name = name.trim(),
                        type = type,
                        colorHex = colorHex,
                        initialBalancePaisa = 0L
                    )
                    db.accountDao().insert(newAccount)
                    if (initialBalancePaisa > 0) {
                        DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "CREATE_ACCOUNT_OPENING")
                        financialService.createOpeningBalance(
                            accountId = newAccount.id,
                            amountPaisa = initialBalancePaisa,
                            description = "প্রারম্ভিক স্থিতি: ${newAccount.name}"
                        )
                    }
                    DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "CREATE_ACCOUNT")
                    _uiState.update { it.copy(snackbarMessage = "নতুন অ্যাকাউন্ট তৈরি হয়েছে: $name") }
                    isSuccess = true
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "CREATE_ACCOUNT")
                    _uiState.update { it.copy(snackbarMessage = "অ্যাকাউন্ট তৈরি করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "CREATE_ACCOUNT")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun executeShortcut(shortcut: FrequentShortcutEntity) {
        viewModelScope.launch(ioDispatcher) {
            withContext(ioDispatcher) {
                try {
                    db.frequentShortcutDao().incrementUsage(shortcut.id)
                    val cat = db.categoryDao().getById(shortcut.defaultCategoryId)
                    val desc = "${shortcut.labelBn} (${cat?.nameBn ?: "মাইক্রো খরচ"})"

                    val result = financialService.addExpense(
                        sourceAccountId = shortcut.defaultAccountId,
                        amountPaisa = shortcut.defaultAmountPaisa,
                        categoryId = shortcut.defaultCategoryId,
                        description = desc
                    )
                    when (result) {
                        is FinancialResult.Success -> {
                            _uiState.update {
                                it.copy(
                                    lastAddedEventId = result.data.id,
                                    snackbarMessage = "${shortcut.labelBn} খরচ যুক্ত হয়েছে (${BengaliFormatter.formatPaisa(shortcut.defaultAmountPaisa, it.useBengaliDigits)})"
                                )
                            }
                        }
                        is FinancialResult.Error -> {
                            _uiState.update { it.copy(snackbarMessage = "ত্রুটি: ${result.message}") }
                        }
                    }
                } catch (e: Exception) {
                    _uiState.update { it.copy(snackbarMessage = "শর্টকাট সম্পাদন করা যায়নি। আবার চেষ্টা করুন।") }
                }
            }
            loadDataInternal()
        }
    }

    fun undoLastAction() {
        val lastId = _uiState.value.lastAddedEventId ?: return
        viewModelScope.launch(ioDispatcher) {
            withContext(ioDispatcher) {
                try {
                    val event = db.ledgerEventDao().getById(lastId)
                    if (event != null) {
                        if (event.confirmationStatus == ConfirmationStatus.DRAFT.name) {
                            db.ledgerEventDao().deleteDraft(lastId)
                            _uiState.update {
                                it.copy(
                                    lastAddedEventId = null,
                                    snackbarMessage = "খসড়া বাতিল করা হয়েছে"
                                )
                            }
                        } else {
                            val revResult = financialService.reverseLedgerEvent(
                                targetEventId = lastId,
                                reversalReason = "ব্যবহারকারী কর্তৃক সাথে সাথে প্রত্যাহার (Undo)"
                            )
                            when (revResult) {
                                is FinancialResult.Success -> {
                                    _uiState.update {
                                        it.copy(
                                            lastAddedEventId = null,
                                            snackbarMessage = "লেনদেনটি সাথে সাথে বাতিল করা হয়েছে"
                                        )
                                    }
                                }
                                is FinancialResult.Error -> {
                                    _uiState.update { it.copy(snackbarMessage = "বাতিল করা সম্ভব হয়নি: ${revResult.message}") }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    _uiState.update { it.copy(snackbarMessage = "বাতিল প্রক্রিয়া ব্যর্থ হয়েছে") }
                }
            }
            loadDataInternal()
        }
    }

    fun reverseTransaction(transactionId: String, reason: String) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "REVERSE_TRANSACTION")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "REVERSE_TRANSACTION")
                    DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "REVERSE_TRANSACTION")
                    val result = financialService.reverseLedgerEvent(
                        targetEventId = transactionId,
                        reversalReason = reason.ifBlank { "ভুল এন্ট্রি সংশোধন" }
                    )
                    when (result) {
                        is FinancialResult.Success -> {
                            DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "REVERSE_TRANSACTION")
                            _uiState.update {
                                it.copy(
                                    snackbarMessage = "লেনদেনটি রিভার্স করা হয়েছে (${result.data.eventCode})"
                                )
                            }
                            isSuccess = true
                        }
                        is FinancialResult.Error -> {
                            DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "REVERSE_TRANSACTION")
                            _uiState.update { it.copy(snackbarMessage = "ত্রুটি: ${result.message}") }
                        }
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "REVERSE_TRANSACTION")
                    _uiState.update { it.copy(snackbarMessage = "রিভার্সাল সংরক্ষণ করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "REVERSE_TRANSACTION")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    fun settleWork(workId: String, destinationAccountId: String, finalPaymentPaisa: Long) {
        DiagnosticService.addCheckpoint("VIEWMODEL_SUBMIT_STARTED", "SETTLE_WORK")
        viewModelScope.launch(ioDispatcher) {
            var isSuccess = false
            withContext(ioDispatcher) {
                try {
                    DiagnosticService.addCheckpoint("VALIDATION_PASSED", "SETTLE_WORK")
                    DiagnosticService.addCheckpoint("FINANCIAL_SERVICE_CALLED", "SETTLE_WORK")
                    val result = financialService.settleAndCompleteWork(
                        workId = workId,
                        accountForFinalSettlementId = destinationAccountId
                    )
                    when (result) {
                        is FinancialResult.Success -> {
                            DiagnosticService.addCheckpoint("UI_SUCCESS_EMITTED", "SETTLE_WORK")
                            _uiState.update {
                                it.copy(
                                    snackbarMessage = "কাজটি চূড়ান্তভাবে নিষ্পত্তি হয়েছে!"
                                )
                            }
                            isSuccess = true
                        }
                        is FinancialResult.Error -> {
                            DiagnosticService.addCheckpoint("UI_ERROR_EMITTED", "SETTLE_WORK")
                            _uiState.update { it.copy(snackbarMessage = "নিষ্পত্তিতে ত্রুটি: ${result.message}") }
                        }
                    }
                } catch (e: Exception) {
                    DiagnosticService.addCheckpoint("UNEXPECTED_FAILURE", "SETTLE_WORK")
                    _uiState.update { it.copy(snackbarMessage = "কাজ নিষ্পত্তি করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।") }
                }
            }
            if (isSuccess) {
                DiagnosticService.addCheckpoint("DIALOG_DISMISS_REQUESTED", "SETTLE_WORK")
                dismissDialog()
                loadDataInternal()
            }
        }
    }

    private suspend fun loadDataInternal() {
        withContext(ioDispatcher) {
            try {
                val appSettings = db.appSettingDao().getAll()
                val useBengali = appSettings.firstOrNull { it.key == "use_bengali_digits" }?.value != "false"

                val accounts = db.accountDao().getAllActive()
                val categories = db.categoryDao().getAll()
                val shortcuts = db.frequentShortcutDao().getAll()
                val persons = db.personDao().getAll()
                val works = db.workDao().getAll()
                val rawEvents = db.ledgerEventDao().getAllNonDeleted()

                val confirmedEvents = rawEvents.filter { it.confirmationStatus == ConfirmationStatus.CONFIRMED.name }

                val accountsWithBal = accounts.map { acc ->
                    val netPaisa = FinancialCalculationEngine.calculateAccountBalance(acc, confirmedEvents)
                    AccountWithBalance(account = acc, currentBalancePaisa = netPaisa)
                }

                val now = Calendar.getInstance()
                val startOfDay = now.apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis

                val startOfMonth = now.apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                }.timeInMillis

                val todaySummary = FinancialCalculationEngine.calculatePeriodSummary(startOfDay, Long.MAX_VALUE, confirmedEvents)
                val monthSummary = FinancialCalculationEngine.calculatePeriodSummary(startOfMonth, Long.MAX_VALUE, confirmedEvents)

                val todayIncurredExpense = todaySummary.incurredExpensePaisa
                val monthIncurredExpense = monthSummary.incurredExpensePaisa
                val monthEarnedIncome = monthSummary.earnedIncomePaisa

                val totalUnearnedAdvancePaisa = FinancialCalculationEngine.calculateTotalUnearnedAdvances(works, confirmedEvents)
                val totalRecognizedReceivablesPaisa = FinancialCalculationEngine.calculateTotalRecognizedReceivables(db.receivableDao().getActive(), confirmedEvents)

                val summary = DashboardSummary(
                    totalLiquidCashPaisa = accountsWithBal.sumOf { it.currentBalancePaisa },
                    todayExpensePaisa = todayIncurredExpense,
                    monthExpensePaisa = monthIncurredExpense,
                    monthEarnedIncomePaisa = monthEarnedIncome,
                    unearnedAdvancePaisa = totalUnearnedAdvancePaisa,
                    activeReceivablePaisa = totalRecognizedReceivablesPaisa,
                    activePayablePaisa = 0L
                )

                val transactionItems = rawEvents.map { ev ->
                    val srcAcc = accounts.firstOrNull { it.id == ev.sourceAccountId }?.name
                    val dstAcc = accounts.firstOrNull { it.id == ev.destinationAccountId }?.name
                    val cat = categories.firstOrNull { it.id == ev.categoryId }
                    val personName = persons.firstOrNull { it.id == ev.personId }?.name
                    val workTitle = works.firstOrNull { it.id == ev.workId }?.title

                    TransactionDisplayItem(
                        id = ev.id,
                        eventCode = ev.eventCode,
                        amountPaisa = ev.amountPaisa,
                        sourceAccountId = ev.sourceAccountId,
                        destinationAccountId = ev.destinationAccountId,
                        sourceAccountName = srcAcc,
                        destinationAccountName = dstAcc,
                        categoryId = ev.categoryId,
                        categoryNameBn = cat?.nameBn,
                        categoryIcon = cat?.iconName,
                        categoryColorHex = cat?.colorHex,
                        personId = ev.personId,
                        personName = personName,
                        workId = ev.workId,
                        workTitle = workTitle,
                        description = ev.description,
                        notes = ev.notes,
                        timestampEpochMs = ev.eventTimestampEpochMs,
                        confirmationStatus = ev.confirmationStatus,
                        originalLedgerEventId = ev.originalLedgerEventId,
                        reversedTransactionId = ev.reversedTransactionId
                    )
                }.sortedByDescending { it.timestampEpochMs }

                val workItems = works.map { w ->
                    val client = persons.firstOrNull { it.id == w.clientId }
                    val linkedEvents = confirmedEvents.filter { it.workId == w.id }
                    val proj = FinancialCalculationEngine.calculateWorkFinancials(w, linkedEvents)

                    WorkDisplayItem(
                        work = w,
                        clientName = client?.name ?: "ক্লায়েন্ট",
                        projection = proj
                    )
                }.sortedByDescending { it.work.createdAtEpochMs }

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        useBengaliDigits = useBengali,
                        dashboardSummary = summary,
                        accountsWithBalance = accountsWithBal,
                        frequentShortcuts = shortcuts,
                        recentTransactions = transactionItems,
                        allTransactions = transactionItems,
                        categories = categories,
                        persons = persons,
                        activeWorks = workItems
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, snackbarMessage = "তথ্য লোড করতে ত্রুটি হয়েছে") }
            }
        }
    }
}

class DiaryViewModelFactory(private val db: AppDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DiaryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DiaryViewModel(db) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
