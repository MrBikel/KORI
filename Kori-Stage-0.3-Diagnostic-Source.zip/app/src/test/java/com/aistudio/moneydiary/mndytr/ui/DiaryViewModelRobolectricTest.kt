package com.aistudio.moneydiary.mndytr.ui

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.aistudio.moneydiary.mndytr.data.local.database.AppDatabase
import com.aistudio.moneydiary.mndytr.domain.model.AccountType
import com.aistudio.moneydiary.mndytr.domain.model.LedgerEventCode
import com.aistudio.moneydiary.mndytr.domain.model.WorkStatus
import com.aistudio.moneydiary.mndytr.domain.service.FinancialService
import com.aistudio.moneydiary.mndytr.ui.screens.SetupAccountDraft
import com.aistudio.moneydiary.mndytr.ui.state.ActiveDialog
import com.aistudio.moneydiary.mndytr.ui.state.AppNavTab
import com.aistudio.moneydiary.mndytr.ui.util.BengaliFormatter
import com.aistudio.moneydiary.mndytr.ui.viewmodel.DiaryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DiaryViewModelRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
        Dispatchers.resetMain()
    }

    private fun createViewModel(): DiaryViewModel {
        return DiaryViewModel(db = db, financialService = FinancialService(db), ioDispatcher = testDispatcher)
    }

    @Test
    fun testFirstLaunchSetupFlow() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        // Complete 9-step setup
        val drafts = listOf(
            SetupAccountDraft(name = "নগদ ক্যাশ", type = "CASH", isEnabled = true, openingBalanceText = "500"),
            SetupAccountDraft(name = "আমার বিকাশ", type = "MFS_BKASH", isEnabled = true, openingBalanceText = "1000"),
            SetupAccountDraft(name = "সঞ্চয় ব্যাংক", type = "SAVINGS", isEnabled = true, openingBalanceText = "2000")
        )

        viewModel.completeFirstLaunchSetup(useBengaliDigits = true, accounts = drafts)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.isSetupCompleted)
        assertEquals(3, state.accountsWithBalance.size)

        // Total opening balance = 500 + 1000 + 2000 = 3500 (350,000 paisa)
        assertEquals(350000L, state.dashboardSummary.totalLiquidCashPaisa)
        // Opening balance MUST create 0 earned income and 0 incurred expense
        assertEquals(0L, state.dashboardSummary.todayExpensePaisa)
        assertEquals(0L, state.dashboardSummary.monthEarnedIncomePaisa)
    }

    @Test
    fun testOpeningBalanceAndExpenseFlow() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        val drafts = listOf(
            SetupAccountDraft(name = "নগদ", type = "CASH", isEnabled = true, openingBalanceText = "500")
        )
        viewModel.completeFirstLaunchSetup(useBengaliDigits = true, accounts = drafts)
        advanceUntilIdle()

        val cashAcc = viewModel.uiState.value.accountsWithBalance.first().account

        // Add tea expense ৳10 (1,000 paisa)
        val teaCat = viewModel.uiState.value.categories.first { it.nameBn.contains("চা") }
        viewModel.addExpense(cashAcc.id, 1000L, teaCat.id, "রং চা", null, false)
        advanceUntilIdle()

        val stateAfterExpense = viewModel.uiState.value
        assertEquals(49000L, stateAfterExpense.dashboardSummary.totalLiquidCashPaisa)
        assertEquals(1000L, stateAfterExpense.dashboardSummary.todayExpensePaisa)
        assertTrue(stateAfterExpense.allTransactions.any { it.description == "রং চা" })
    }

    @Test
    fun testFrequentShortcutExecutionAndUndo() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        val drafts = listOf(
            SetupAccountDraft(name = "নগদ", type = "CASH", isEnabled = true, openingBalanceText = "200")
        )
        viewModel.completeFirstLaunchSetup(useBengaliDigits = true, accounts = drafts)
        advanceUntilIdle()

        val cigaretteShortcut = viewModel.uiState.value.frequentShortcuts.first { it.labelBn == "সিগারেট" }
        viewModel.executeShortcut(cigaretteShortcut)
        advanceUntilIdle()

        // ৳200 - ৳20 = ৳180 (18,000 paisa)
        assertEquals(18000L, viewModel.uiState.value.dashboardSummary.totalLiquidCashPaisa)
        assertNotNull(viewModel.uiState.value.lastAddedEventId)

        // Test immediate undo
        viewModel.undoLastAction()
        advanceUntilIdle()

        // Balance restored back to ৳200 (20,000 paisa)
        assertEquals(20000L, viewModel.uiState.value.dashboardSummary.totalLiquidCashPaisa)
    }

    @Test
    fun testWorkAdvanceAndSettlementFinancialInvariants() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        val drafts = listOf(
            SetupAccountDraft(name = "নগদ", type = "CASH", isEnabled = true, openingBalanceText = "0")
        )
        viewModel.completeFirstLaunchSetup(useBengaliDigits = true, accounts = drafts)
        advanceUntilIdle()

        val cashAcc = viewModel.uiState.value.accountsWithBalance.first().account

        // Add work with ৳500 total, ৳100 advance
        viewModel.addWorkAdvance(
            clientName = "তানভীর ভাই",
            workTitle = "লোগো ডিজাইন",
            agreedTotalPaisa = 50000L, // ৳500
            advanceReceivedPaisa = 10000L, // ৳100
            destinationAccountId = cashAcc.id
        )
        advanceUntilIdle()

        val state = viewModel.uiState.value
        // Cash increased by ৳100
        assertEquals(10000L, state.dashboardSummary.totalLiquidCashPaisa)
        // Advance liability increased by ৳100
        assertEquals(10000L, state.dashboardSummary.unearnedAdvancePaisa)
        // Earned income MUST BE 0!
        assertEquals(0L, state.dashboardSummary.monthEarnedIncomePaisa)

        // Settle work with final payment of ৳400
        val workItem = state.activeWorks.first { it.work.title == "লোগো ডিজাইন" }
        viewModel.settleWork(workItem.work.id, cashAcc.id, 40000L) // ৳400
        advanceUntilIdle()

        val settledState = viewModel.uiState.value
        // Total cash: ৳100 advance + ৳400 final = ৳500
        assertEquals(50000L, settledState.dashboardSummary.totalLiquidCashPaisa)
        // Advance liability is now 0
        assertEquals(0L, settledState.dashboardSummary.unearnedAdvancePaisa)
        // Earned income is now exactly ৳500
        assertEquals(50000L, settledState.dashboardSummary.monthEarnedIncomePaisa)
        // Work is marked completed
        assertEquals(WorkStatus.COMPLETED.name, settledState.activeWorks.first().work.workStatus)
    }

    @Test
    fun testTransferWithFee() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        val drafts = listOf(
            SetupAccountDraft(name = "নগদ", type = "CASH", isEnabled = true, openingBalanceText = "2000"),
            SetupAccountDraft(name = "bKash", type = "MFS_BKASH", isEnabled = true, openingBalanceText = "0")
        )
        viewModel.completeFirstLaunchSetup(useBengaliDigits = true, accounts = drafts)
        advanceUntilIdle()

        val cashAcc = viewModel.uiState.value.accountsWithBalance.first { it.account.type == "CASH" }.account
        val bkashAcc = viewModel.uiState.value.accountsWithBalance.first { it.account.type == "MFS_BKASH" }.account

        // Transfer ৳1,000 from Cash to bKash with ৳20 fee
        viewModel.transferFunds(
            sourceAccountId = cashAcc.id,
            destinationAccountId = bkashAcc.id,
            amountPaisa = 100000L, // ৳1,000
            feePaisa = 2000L // ৳20
        )
        advanceUntilIdle()

        val state = viewModel.uiState.value
        val cashBal = state.accountsWithBalance.first { it.account.id == cashAcc.id }.currentBalancePaisa
        val bkashBal = state.accountsWithBalance.first { it.account.id == bkashAcc.id }.currentBalancePaisa

        // Cash: 2,000 - (1,000 + 20) = 980 (98,000 paisa)
        assertEquals(98000L, cashBal)
        // bKash: + 1,000 = 1,000 (100,000 paisa)
        assertEquals(100000L, bkashBal)
        // Total liquid cash: 980 + 1000 = 1980 (decreased by fee 20)
        assertEquals(198000L, state.dashboardSummary.totalLiquidCashPaisa)
        // Incurred expense is fee only (৳20)
        assertEquals(2000L, state.dashboardSummary.todayExpensePaisa)
        // Earned income = 0
        assertEquals(0L, state.dashboardSummary.monthEarnedIncomePaisa)
    }

    @Test
    fun testSavingsAllocation() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        val drafts = listOf(
            SetupAccountDraft(name = "নগদ", type = "CASH", isEnabled = true, openingBalanceText = "5000"),
            SetupAccountDraft(name = "ডিপিএস সঞ্চয়", type = "SAVINGS", isEnabled = true, openingBalanceText = "0")
        )
        viewModel.completeFirstLaunchSetup(useBengaliDigits = true, accounts = drafts)
        advanceUntilIdle()

        val cashAcc = viewModel.uiState.value.accountsWithBalance.first { it.account.type == "CASH" }.account
        val savingsAcc = viewModel.uiState.value.accountsWithBalance.first { it.account.type == "SAVINGS" }.account

        // Allocate ৳2,000 to Savings
        viewModel.allocateSavings(
            sourceAccountId = cashAcc.id,
            destinationAccountId = savingsAcc.id,
            amountPaisa = 200000L, // ৳2,000
            note = "মাসিক ডিপিএস"
        )
        advanceUntilIdle()

        val state = viewModel.uiState.value
        val cashBal = state.accountsWithBalance.first { it.account.id == cashAcc.id }.currentBalancePaisa
        val savingsBal = state.accountsWithBalance.first { it.account.id == savingsAcc.id }.currentBalancePaisa

        assertEquals(300000L, cashBal) // ৳3,000
        assertEquals(200000L, savingsBal) // ৳2,000
        // Net worth unchanged: 3000 + 2000 = 5000 (500,000 paisa)
        assertEquals(500000L, state.dashboardSummary.totalLiquidCashPaisa)
        // Income = 0, Expense = 0
        assertEquals(0L, state.dashboardSummary.todayExpensePaisa)
        assertEquals(0L, state.dashboardSummary.monthEarnedIncomePaisa)
    }

    @Test
    fun testTransactionReversal() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        val drafts = listOf(
            SetupAccountDraft(name = "নগদ", type = "CASH", isEnabled = true, openingBalanceText = "100")
        )
        viewModel.completeFirstLaunchSetup(useBengaliDigits = true, accounts = drafts)
        advanceUntilIdle()

        val cashAcc = viewModel.uiState.value.accountsWithBalance.first().account
        val cat = viewModel.uiState.value.categories.first { !it.isIncomeCategory }

        viewModel.addExpense(cashAcc.id, 3000L, cat.id, "রিকশা ভাড়া", null, false)
        advanceUntilIdle()

        assertEquals(7000L, viewModel.uiState.value.dashboardSummary.totalLiquidCashPaisa)
        val expenseEvent = viewModel.uiState.value.recentTransactions.first { it.eventCode == LedgerEventCode.TX_02_EXPENSE.name }

        // Reverse the expense
        viewModel.reverseTransaction(expenseEvent.id, "ভুল রিকশা ভাড়া এন্ট্রি")
        advanceUntilIdle()

        val afterRevState = viewModel.uiState.value
        // Balance restored back to ৳100 (10,000 paisa)
        assertEquals(10000L, afterRevState.dashboardSummary.totalLiquidCashPaisa)
        // Reversal event exists
        assertTrue(afterRevState.recentTransactions.any { it.eventCode == LedgerEventCode.TX_17_REVERSAL.name })
    }

    @Test
    fun testBengaliFormatterAndDigits() {
        val bengaliFormatted = BengaliFormatter.formatPaisa(125000L, useBengaliDigits = true, showDecimals = false)
        assertEquals("৳ ১,২৫০", bengaliFormatted)

        val englishFormatted = BengaliFormatter.formatPaisa(125000L, useBengaliDigits = false, showDecimals = false)
        assertEquals("৳ 1,250", englishFormatted)

        val parsedFromBengali = BengaliFormatter.parseAmountToPaisa("৳ ১,২৫০")
        assertEquals(125000L, parsedFromBengali)

        val parsedFromEnglish = BengaliFormatter.parseAmountToPaisa("1250")
        assertEquals(125000L, parsedFromEnglish)
    }

    @Test
    fun testTabNavigationAndDialogState() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        assertEquals(AppNavTab.DASHBOARD, viewModel.uiState.value.selectedTab)
        viewModel.selectTab(AppNavTab.TRANSACTIONS)
        assertEquals(AppNavTab.TRANSACTIONS, viewModel.uiState.value.selectedTab)

        viewModel.openDialog(ActiveDialog.SavingsAllocation)
        assertEquals(ActiveDialog.SavingsAllocation, viewModel.uiState.value.activeDialog)

        viewModel.dismissDialog()
        assertEquals(ActiveDialog.None, viewModel.uiState.value.activeDialog)
    }

    @Test
    fun testInvalidSubmissionKeepsDialogOpenAndShowsError() = runTest(testDispatcher) {
        val viewModel = createViewModel()
        advanceUntilIdle()

        // Open Add Expense dialog
        viewModel.openDialog(ActiveDialog.AddExpense)
        assertEquals(ActiveDialog.AddExpense, viewModel.uiState.value.activeDialog)

        // Submit expense with invalid non-existent account ID
        viewModel.addExpense(
            accountId = "invalid_acc_999",
            amountPaisa = 1000L,
            categoryId = "non_existent_cat",
            description = "Test expense"
        )
        advanceUntilIdle()

        val state = viewModel.uiState.value
        // Verify application did NOT crash and dialog remains OPEN
        assertEquals(ActiveDialog.AddExpense, state.activeDialog)
        // Verify safe error message in snackbar
        assertNotNull(state.snackbarMessage)
        assertTrue(state.snackbarMessage!!.contains("ত্রুটি") || state.snackbarMessage!!.contains("পাওয়া যায়নি") || state.snackbarMessage!!.contains("সংরক্ষণ করা যায়নি"))
    }
}
