package com.aistudio.moneydiary.mndytr

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.aistudio.moneydiary.mndytr.data.local.database.AppDatabase
import com.aistudio.moneydiary.mndytr.ui.screens.MainAppScreen
import com.aistudio.moneydiary.mndytr.ui.theme.MyApplicationTheme
import com.aistudio.moneydiary.mndytr.ui.viewmodel.DiaryViewModel
import com.aistudio.moneydiary.mndytr.ui.viewmodel.DiaryViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getInstance(applicationContext)
        val viewModel = ViewModelProvider(this, DiaryViewModelFactory(db))[DiaryViewModel::class.java]

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}
