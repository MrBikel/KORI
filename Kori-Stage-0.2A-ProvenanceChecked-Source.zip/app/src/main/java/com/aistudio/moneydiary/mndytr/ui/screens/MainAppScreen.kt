package com.aistudio.moneydiary.mndytr.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.moneydiary.mndytr.ui.dialogs.AddAccountDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.AddExpenseDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.AddIncomeDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.AddWorkAdvanceDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.OpeningBalanceDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.ReverseTransactionDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.SavingsAllocationDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.SettleWorkDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.SmartEntryDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.TransactionDetailDialog
import com.aistudio.moneydiary.mndytr.ui.dialogs.TransferDialog
import com.aistudio.moneydiary.mndytr.ui.state.ActiveDialog
import com.aistudio.moneydiary.mndytr.ui.state.AppNavTab
import com.aistudio.moneydiary.mndytr.ui.theme.PrimaryEmerald
import com.aistudio.moneydiary.mndytr.ui.theme.SecondaryGold
import com.aistudio.moneydiary.mndytr.ui.viewmodel.DiaryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: DiaryViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // First Launch Setup Screen Guard
    if (!state.isSetupCompleted && !state.isLoading) {
        FirstLaunchSetupScreen(
            onCompleteSetup = { useBengaliDigits, accounts ->
                viewModel.completeFirstLaunchSetup(useBengaliDigits, accounts)
            }
        )
        return
    }

    if (state.isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryEmerald)
        }
        return
    }

    // Handle back button: return to dashboard if on another tab
    BackHandler(enabled = state.selectedTab != AppNavTab.DASHBOARD || state.activeDialog != ActiveDialog.None) {
        if (state.activeDialog != ActiveDialog.None) {
            viewModel.dismissDialog()
        } else {
            viewModel.selectTab(AppNavTab.DASHBOARD)
        }
    }

    // Snackbar notifications with Undo support
    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            val hasUndo = state.lastAddedEventId != null
            val result = snackbarHostState.showSnackbar(
                message = msg,
                actionLabel = if (hasUndo) "বাতিল (Undo)" else null,
                duration = if (hasUndo) SnackbarDuration.Short else SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) {
                viewModel.undoLastAction()
            }
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(SecondaryGold),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "৳",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "কড়ি",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "নিরাপদ ও ব্যক্তিগত খাতা",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            )
                        }
                    }
                },
                actions = {
                    // Smart Entry Shorthand Assistant Button
                    IconButton(
                        onClick = { viewModel.openDialog(ActiveDialog.SmartEntry) },
                        modifier = Modifier.testTag("top_smart_entry_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Smart Entry",
                            tint = SecondaryGold
                        )
                    }

                    // Numeral toggle: বাংলা / 123
                    FilterChip(
                        selected = state.useBengaliDigits,
                        onClick = { viewModel.toggleBengaliDigits() },
                        label = {
                            Text(
                                text = if (state.useBengaliDigits) "বাংলা (১২৩)" else "English (123)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = SecondaryGold,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        modifier = Modifier.padding(end = 8.dp).testTag("numeral_toggle_chip")
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryEmerald,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.DASHBOARD,
                    onClick = { viewModel.selectTab(AppNavTab.DASHBOARD) },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Dashboard") },
                    label = { Text("ড্যাশবোর্ড") },
                    modifier = Modifier.testTag("nav_dashboard")
                )

                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.TRANSACTIONS,
                    onClick = { viewModel.selectTab(AppNavTab.TRANSACTIONS) },
                    icon = { Icon(Icons.AutoMirrored.Filled.ReceiptLong, contentDescription = "Transactions") },
                    label = { Text("লেনদেন") },
                    modifier = Modifier.testTag("nav_transactions")
                )

                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.ACCOUNTS,
                    onClick = { viewModel.selectTab(AppNavTab.ACCOUNTS) },
                    icon = { Icon(Icons.Default.AccountBalance, contentDescription = "Accounts") },
                    label = { Text("হিসাবসমূহ") },
                    modifier = Modifier.testTag("nav_accounts")
                )

                NavigationBarItem(
                    selected = state.selectedTab == AppNavTab.WORKS,
                    onClick = { viewModel.selectTab(AppNavTab.WORKS) },
                    icon = { Icon(Icons.Default.Work, contentDescription = "Works") },
                    label = { Text("কাজের চুক্তি") },
                    modifier = Modifier.testTag("nav_works")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (state.selectedTab) {
                AppNavTab.DASHBOARD -> DashboardScreen(
                    state = state,
                    onOpenDialog = { viewModel.openDialog(it) },
                    onSelectTab = { viewModel.selectTab(it) },
                    onExecuteShortcut = { viewModel.executeShortcut(it) }
                )
                AppNavTab.TRANSACTIONS -> TransactionsScreen(
                    state = state,
                    onOpenDialog = { viewModel.openDialog(it) }
                )
                AppNavTab.ACCOUNTS -> AccountsScreen(
                    state = state,
                    onOpenDialog = { viewModel.openDialog(it) }
                )
                AppNavTab.WORKS -> WorksScreen(
                    state = state,
                    onOpenDialog = { viewModel.openDialog(it) }
                )
            }
        }
    }

    // Active Dialog Controller
    when (val dialog = state.activeDialog) {
        ActiveDialog.None -> { /* No Dialog */ }
        ActiveDialog.AddExpense -> {
            AddExpenseDialog(
                categories = state.categories,
                accounts = state.accountsWithBalance.map { it.account },
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { accId, amt, catId, desc, notes, isDraft ->
                    viewModel.addExpense(accId, amt, catId, desc, notes, isDraft)
                }
            )
        }
        ActiveDialog.AddIncome -> {
            AddIncomeDialog(
                categories = state.categories,
                accounts = state.accountsWithBalance.map { it.account },
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { accId, amt, catId, personId, desc, notes ->
                    viewModel.addIncome(accId, amt, catId, personId, desc, notes)
                }
            )
        }
        ActiveDialog.AddWorkAdvance -> {
            AddWorkAdvanceDialog(
                accounts = state.accountsWithBalance.map { it.account },
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { clientName, title, totalPaisa, advPaisa, accId, notes ->
                    viewModel.addWorkAdvance(clientName, title, totalPaisa, advPaisa, accId, notes)
                }
            )
        }
        ActiveDialog.Transfer -> {
            TransferDialog(
                accounts = state.accountsWithBalance.map { it.account },
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { srcId, dstId, amt, fee, desc ->
                    viewModel.transferFunds(srcId, dstId, amt, fee, desc)
                }
            )
        }
        ActiveDialog.SavingsAllocation -> {
            SavingsAllocationDialog(
                accountsWithBalance = state.accountsWithBalance,
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { srcId, dstId, amt, note ->
                    viewModel.allocateSavings(srcId, dstId, amt, note)
                }
            )
        }
        ActiveDialog.SmartEntry -> {
            SmartEntryDialog(
                availableAccounts = state.accountsWithBalance.map { it.account },
                availableCategories = state.categories,
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirmExpense = { accId, amt, catId, desc ->
                    viewModel.addExpense(accId, amt, catId, desc, null, false)
                },
                onConfirmIncome = { accId, amt, catId, desc ->
                    viewModel.addIncome(accId, amt, catId, null, desc, null)
                },
                onConfirmWorkAdvance = { clientName, title, totalPaisa, advPaisa, accId ->
                    viewModel.addWorkAdvance(clientName, title, totalPaisa, advPaisa, accId, null)
                }
            )
        }
        is ActiveDialog.OpeningBalance -> {
            OpeningBalanceDialog(
                accounts = state.accountsWithBalance.map { it.account },
                preSelectedAccountId = dialog.accountId,
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { accId, amt, desc ->
                    viewModel.setOpeningBalance(accId, amt, desc)
                }
            )
        }
        ActiveDialog.AddAccount -> {
            AddAccountDialog(
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { name, type, color, initBal ->
                    viewModel.createAccount(name, type, color, initBal)
                }
            )
        }
        is ActiveDialog.SettleWork -> {
            val workItem = state.activeWorks.find { it.work.id == dialog.workId }
            if (workItem != null) {
                SettleWorkDialog(
                    workDisplay = workItem,
                    accounts = state.accountsWithBalance.map { it.account },
                    useBengaliDigits = state.useBengaliDigits,
                    onDismiss = { viewModel.dismissDialog() },
                    onConfirm = { workId, dstAccId, finalPaymentPaisa ->
                        viewModel.settleWork(workId, dstAccId, finalPaymentPaisa)
                    }
                )
            }
        }
        is ActiveDialog.TransactionDetail -> {
            TransactionDetailDialog(
                item = dialog.item,
                useBengaliDigits = state.useBengaliDigits,
                onDismiss = { viewModel.dismissDialog() },
                onReverseRequest = {
                    viewModel.openDialog(ActiveDialog.ReverseTransaction(dialog.item.id, dialog.item.description))
                },
                onDeleteDraftRequest = {
                    viewModel.undoLastAction()
                    viewModel.dismissDialog()
                }
            )
        }
        is ActiveDialog.ReverseTransaction -> {
            ReverseTransactionDialog(
                transactionId = dialog.transactionId,
                description = dialog.description,
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { reason ->
                    viewModel.reverseTransaction(dialog.transactionId, reason)
                }
            )
        }
    }
}
