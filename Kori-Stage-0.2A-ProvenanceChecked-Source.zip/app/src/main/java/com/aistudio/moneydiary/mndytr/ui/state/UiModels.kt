package com.aistudio.moneydiary.mndytr.ui.state

import com.aistudio.moneydiary.mndytr.data.local.entity.AccountEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.CategoryEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.FrequentShortcutEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.PersonEntity
import com.aistudio.moneydiary.mndytr.data.local.entity.WorkRecordEntity
import com.aistudio.moneydiary.mndytr.domain.model.WorkFinancialProjection

data class AccountWithBalance(
    val account: AccountEntity,
    val currentBalancePaisa: Long
)

data class TransactionDisplayItem(
    val id: String,
    val eventCode: String,
    val amountPaisa: Long,
    val sourceAccountId: String? = null,
    val destinationAccountId: String? = null,
    val sourceAccountName: String? = null,
    val destinationAccountName: String? = null,
    val categoryId: String? = null,
    val categoryNameBn: String? = null,
    val categoryIcon: String? = null,
    val categoryColorHex: String? = null,
    val personId: String? = null,
    val personName: String? = null,
    val workId: String? = null,
    val workTitle: String? = null,
    val description: String,
    val notes: String? = null,
    val timestampEpochMs: Long,
    val confirmationStatus: String,
    val originalLedgerEventId: String? = null,
    val reversedTransactionId: String? = null,
    val isDraft: Boolean = false,
    val isReversible: Boolean = true
)

data class WorkDisplayItem(
    val work: WorkRecordEntity,
    val clientName: String,
    val projection: WorkFinancialProjection
)

data class DashboardSummary(
    val totalLiquidCashPaisa: Long = 0L,
    val todayExpensePaisa: Long = 0L,
    val monthExpensePaisa: Long = 0L,
    val monthEarnedIncomePaisa: Long = 0L,
    val unearnedAdvancePaisa: Long = 0L,
    val activeReceivablePaisa: Long = 0L,
    val activePayablePaisa: Long = 0L
)

enum class AppNavTab(val labelBn: String) {
    DASHBOARD("ড্যাশবোর্ড"),
    TRANSACTIONS("লেনদেন"),
    ACCOUNTS("হিসাবসমূহ"),
    WORKS("কাজের চুক্তি")
}

sealed class ActiveDialog {
    object None : ActiveDialog()
    object AddExpense : ActiveDialog()
    object AddIncome : ActiveDialog()
    object AddWorkAdvance : ActiveDialog()
    object Transfer : ActiveDialog()
    object SavingsAllocation : ActiveDialog()
    object SmartEntry : ActiveDialog()
    data class OpeningBalance(val accountId: String? = null) : ActiveDialog()
    object AddAccount : ActiveDialog()
    data class SettleWork(val workId: String) : ActiveDialog()
    data class ReverseTransaction(val transactionId: String, val description: String) : ActiveDialog()
    data class TransactionDetail(val item: TransactionDisplayItem) : ActiveDialog()
}

data class DiaryUiState(
    val isLoading: Boolean = true,
    val isSetupCompleted: Boolean = true,
    val useBengaliDigits: Boolean = true,
    val selectedTab: AppNavTab = AppNavTab.DASHBOARD,
    val activeDialog: ActiveDialog = ActiveDialog.None,
    val dashboardSummary: DashboardSummary = DashboardSummary(),
    val accountsWithBalance: List<AccountWithBalance> = emptyList(),
    val frequentShortcuts: List<FrequentShortcutEntity> = emptyList(),
    val recentTransactions: List<TransactionDisplayItem> = emptyList(),
    val allTransactions: List<TransactionDisplayItem> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val persons: List<PersonEntity> = emptyList(),
    val activeWorks: List<WorkDisplayItem> = emptyList(),
    val snackbarMessage: String? = null,
    val lastAddedEventId: String? = null
)
